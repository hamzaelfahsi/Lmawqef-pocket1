import { eq, and, desc, sql } from "drizzle-orm";
import { z } from "zod";
import { createRouter, publicQuery, authedQuery, adminQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { categories, services, serviceImages, bookings, users } from "@db/schema";

export const serviceRouter = createRouter({
  listCategories: publicQuery.query(async () => {
    const db = getDb();
    return db.query.categories.findMany({ orderBy: categories.displayOrder });
  }),

  createCategory: adminQuery
    .input(z.object({ name: z.string().min(1), slug: z.string().min(1), icon: z.string().optional(), color: z.string().optional(), description: z.string().optional() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const res = await db.insert(categories).values(input);
      return res;
    }),

  listServices: publicQuery
    .input(
      z.object({
        categoryId: z.number().optional(),
        city: z.string().optional(),
        search: z.string().optional(),
        minPrice: z.number().optional(),
        maxPrice: z.number().optional(),
        isUrgent: z.boolean().optional(),
        limit: z.number().default(20),
        offset: z.number().default(0),
      })
    )
    .query(async ({ input }) => {
      const db = getDb();
      const conditions = [eq(services.isActive, true)];
      if (input.categoryId) conditions.push(eq(services.categoryId, input.categoryId));
      if (input.city) conditions.push(eq(services.city, input.city));
      if (input.search) conditions.push(sql`${services.title} LIKE ${`%${input.search}%`}`);
      if (input.minPrice !== undefined) conditions.push(sql`${services.price} >= ${input.minPrice}`);
      if (input.maxPrice !== undefined) conditions.push(sql`${services.price} <= ${input.maxPrice}`);
      if (input.isUrgent !== undefined) conditions.push(eq(services.isUrgent, input.isUrgent));

      const list = await db.query.services.findMany({
        where: and(...conditions),
        limit: input.limit,
        offset: input.offset,
        orderBy: [desc(services.createdAt)],
        with: { worker: true, category: true, images: true },
      });
      return list;
    }),

  getService: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const svc = await db.query.services.findFirst({
        where: eq(services.id, input.id),
        with: { worker: { with: { portfolioItems: true } }, category: true, images: true },
      });
      if (svc) {
        await db.update(services).set({ viewCount: svc.viewCount + 1 }).where(eq(services.id, input.id));
      }
      return svc;
    }),

  createService: authedQuery
    .input(
      z.object({
        categoryId: z.number(),
        title: z.string().min(3).max(255),
        description: z.string().min(10).max(5000),
        price: z.string().or(z.number()),
        priceType: z.enum(["fixed", "hourly", "quote"]).default("fixed"),
        city: z.string().min(1),
        isUrgent: z.boolean().default(false),
        urgentMultiplier: z.string().or(z.number()).optional(),
        images: z.array(z.string()).optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const price = typeof input.price === "string" ? parseFloat(input.price) : input.price;
      const mult = input.urgentMultiplier ? (typeof input.urgentMultiplier === "string" ? parseFloat(input.urgentMultiplier) : input.urgentMultiplier) : 1.5;
      const [svc] = await db.insert(services).values({
        workerId: ctx.user.id,
        categoryId: input.categoryId,
        title: input.title,
        description: input.description,
        price: price.toFixed(2),
        priceType: input.priceType,
        city: input.city,
        isUrgent: input.isUrgent,
        urgentMultiplier: mult.toFixed(2),
      }).$returningId();
      const serviceId = svc.id;
      if (input.images && input.images.length > 0) {
        await db.insert(serviceImages).values(input.images.map((url, i) => ({ serviceId, imageUrl: url, displayOrder: i })));
      }
      return { id: serviceId };
    }),

  updateService: authedQuery
    .input(
      z.object({
        id: z.number(),
        title: z.string().optional(),
        description: z.string().optional(),
        price: z.string().or(z.number()).optional(),
        priceType: z.enum(["fixed", "hourly", "quote"]).optional(),
        city: z.string().optional(),
        isUrgent: z.boolean().optional(),
        isActive: z.boolean().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const existing = await db.query.services.findFirst({
        where: and(eq(services.id, input.id), eq(services.workerId, ctx.user.id)),
      });
      if (!existing) throw new Error("Not authorized");
      const updates: any = { updatedAt: new Date() };
      if (input.title) updates.title = input.title;
      if (input.description) updates.description = input.description;
      if (input.price !== undefined) updates.price = typeof input.price === "string" ? parseFloat(input.price) : input.price;
      if (input.priceType) updates.priceType = input.priceType;
      if (input.city) updates.city = input.city;
      if (input.isUrgent !== undefined) updates.isUrgent = input.isUrgent;
      if (input.isActive !== undefined) updates.isActive = input.isActive;
      await db.update(services).set(updates).where(eq(services.id, input.id));
      return { success: true };
    }),

  deleteService: authedQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const existing = await db.query.services.findFirst({
        where: and(eq(services.id, input.id), eq(services.workerId, ctx.user.id)),
      });
      if (!existing) throw new Error("Not authorized");
      await db.delete(serviceImages).where(eq(serviceImages.serviceId, input.id));
      await db.delete(services).where(eq(services.id, input.id));
      return { success: true };
    }),

  // Bookings
  createBooking: authedQuery
    .input(
      z.object({
        serviceId: z.number(),
        workerId: z.number(),
        date: z.string().or(z.date()),
        notes: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const svc = await db.query.services.findFirst({ where: eq(services.id, input.serviceId) });
      if (!svc) throw new Error("Service not found");
      const bookingDate = typeof input.date === "string" ? new Date(input.date) : input.date;
      const price = parseFloat(svc.price.toString());
      const commission = (price * 0.1).toFixed(2);
      const [booking] = await db.insert(bookings).values({
        clientId: ctx.user.id,
        workerId: input.workerId,
        serviceId: input.serviceId,
        date: bookingDate,
        notes: input.notes,
        price: price.toFixed(2),
        commission,
      }).$returningId();
      return { id: booking.id };
    }),

  listMyBookings: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const asClient = await db.query.bookings.findMany({
      where: eq(bookings.clientId, ctx.user.id),
      orderBy: desc(bookings.createdAt),
      with: { worker: true, service: true },
    });
    const asWorker = await db.query.bookings.findMany({
      where: eq(bookings.workerId, ctx.user.id),
      orderBy: desc(bookings.createdAt),
      with: { client: true, service: true },
    });
    return { asClient, asWorker };
  }),

  updateBookingStatus: authedQuery
    .input(z.object({ id: z.number(), status: z.enum(["pending", "confirmed", "in_progress", "completed", "cancelled", "disputed"]) }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const booking = await db.query.bookings.findFirst({ where: eq(bookings.id, input.id) });
      if (!booking) throw new Error("Booking not found");
      if (booking.clientId !== ctx.user.id && booking.workerId !== ctx.user.id && ctx.user.role !== "admin" && ctx.user.role !== "superadmin") {
        throw new Error("Not authorized");
      }
      const updates: any = { status: input.status, updatedAt: new Date() };
      if (input.status === "completed") {
        updates.commission = booking.commission;
        // Update worker stats
        await db.update(users).set({
          completedJobs: sql`${users.completedJobs} + 1`,
          updatedAt: new Date(),
        }).where(eq(users.id, booking.workerId));
      }
      await db.update(bookings).set(updates).where(eq(bookings.id, input.id));
      return { success: true };
    }),

  addReview: authedQuery
    .input(z.object({ id: z.number(), rating: z.number().min(1).max(5), review: z.string().min(3).max(2000) }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const booking = await db.query.bookings.findFirst({ where: eq(bookings.id, input.id) });
      if (!booking || booking.clientId !== ctx.user.id) throw new Error("Not authorized");
      await db.update(bookings).set({
        rating: input.rating,
        review: input.review,
        reviewedAt: new Date(),
        updatedAt: new Date(),
      }).where(eq(bookings.id, input.id));
      // Recalculate worker rating
      const workerBookings = await db.query.bookings.findMany({
        where: and(eq(bookings.workerId, booking.workerId), sql`${bookings.rating} IS NOT NULL`),
      });
      const avg = workerBookings.reduce((s, b) => s + (b.rating || 0), 0) / workerBookings.length;
      await db.update(users).set({
        rating: avg.toFixed(1),
        reviewCount: workerBookings.length,
        updatedAt: new Date(),
      }).where(eq(users.id, booking.workerId));
      return { success: true };
    }),
});
