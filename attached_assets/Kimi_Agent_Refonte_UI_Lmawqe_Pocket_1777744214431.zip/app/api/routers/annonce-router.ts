import { eq, and, desc } from "drizzle-orm";
import { z } from "zod";
import { createRouter, publicQuery, authedQuery, adminQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { annonces, users, devis, devisItems } from "@db/schema";

export const annonceRouter = createRouter({
  listAnnonces: publicQuery
    .input(z.object({ city: z.string().optional(), categoryId: z.number().optional(), isUrgent: z.boolean().optional(), limit: z.number().default(20), offset: z.number().default(0) }))
    .query(async ({ input }) => {
      const db = getDb();
      const conditions = [eq(annonces.status, "active")];
      if (input.city) conditions.push(eq(annonces.city, input.city));
      if (input.categoryId) conditions.push(eq(annonces.categoryId, input.categoryId));
      if (input.isUrgent !== undefined) conditions.push(eq(annonces.isUrgent, input.isUrgent));
      return db.query.annonces.findMany({
        where: and(...conditions),
        limit: input.limit,
        offset: input.offset,
        orderBy: [desc(annonces.createdAt)],
        with: { user: true, category: true },
      });
    }),

  getAnnonce: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const a = await db.query.annonces.findFirst({
        where: eq(annonces.id, input.id),
        with: { user: true, category: true },
      });
      if (a) {
        await db.update(annonces).set({ views: a.views + 1 }).where(eq(annonces.id, input.id));
      }
      return a;
    }),

  createAnnonce: authedQuery
    .input(z.object({
      title: z.string().min(3).max(255),
      description: z.string().min(10).max(5000),
      categoryId: z.number(),
      city: z.string().min(1),
      budget: z.number().optional(),
      isUrgent: z.boolean().default(false),
    }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const user = await db.query.users.findFirst({ where: eq(users.id, ctx.user.id) });
      const isFree = user && user.freeAnnoncesUsed < 5;
      const [ann] = await db.insert(annonces).values({
        userId: ctx.user.id,
        ...input,
        budget: input.budget ? input.budget.toFixed(2) : null,
        isPaid: isFree,
        status: isFree ? "active" : "pending",
      }).$returningId();
      if (isFree && user) {
        await db.update(users).set({ freeAnnoncesUsed: user.freeAnnoncesUsed + 1 }).where(eq(users.id, ctx.user.id));
      }
      return { id: ann.id, needsPayment: !isFree };
    }),

  listMyAnnonces: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    return db.query.annonces.findMany({
      where: eq(annonces.userId, ctx.user.id),
      orderBy: desc(annonces.createdAt),
      with: { category: true },
    });
  }),

  // Admin
  listAllAnnonces: adminQuery.query(async () => {
    const db = getDb();
    return db.query.annonces.findMany({
      orderBy: desc(annonces.createdAt),
      with: { user: true, category: true },
    });
  }),

  updateAnnonceStatus: adminQuery
    .input(z.object({ id: z.number(), status: z.enum(["pending", "active", "completed", "cancelled"]) }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.update(annonces).set({ status: input.status }).where(eq(annonces.id, input.id));
      return { success: true };
    }),
});

export const devisRouter = createRouter({
  createDevis: authedQuery
    .input(z.object({
      clientId: z.number(),
      bookingId: z.number().optional(),
      title: z.string().min(1),
      description: z.string().optional(),
      items: z.array(z.object({ description: z.string().min(1), quantity: z.number().min(1), unitPrice: z.number().positive() })).min(1),
      taxRate: z.number().default(20),
      validUntil: z.string().or(z.date()).optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const subtotal = input.items.reduce((s, i) => s + i.quantity * i.unitPrice, 0);
      const taxAmount = subtotal * (input.taxRate / 100);
      const total = subtotal + taxAmount;
      const validUntil = input.validUntil ? (typeof input.validUntil === "string" ? new Date(input.validUntil) : input.validUntil) : new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
      const [d] = await db.insert(devis).values({
        workerId: ctx.user.id,
        clientId: input.clientId,
        bookingId: input.bookingId,
        title: input.title,
        description: input.description,
        subtotal: subtotal.toFixed(2),
        taxRate: input.taxRate.toFixed(2),
        taxAmount: taxAmount.toFixed(2),
        total: total.toFixed(2),
        validUntil,
      }).$returningId();
      await db.insert(devisItems).values(input.items.map(i => ({
        devisId: d.id,
        description: i.description,
        quantity: i.quantity,
        unitPrice: i.unitPrice.toFixed(2),
        total: (i.quantity * i.unitPrice).toFixed(2),
      })));
      return { id: d.id };
    }),

  listMyDevis: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const sent = await db.query.devis.findMany({
      where: eq(devis.workerId, ctx.user.id),
      orderBy: desc(devis.createdAt),
      with: { client: true, items: true },
    });
    const received = await db.query.devis.findMany({
      where: eq(devis.clientId, ctx.user.id),
      orderBy: desc(devis.createdAt),
      with: { worker: true, items: true },
    });
    return { sent, received };
  }),

  getDevis: authedQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ ctx, input }) => {
      const db = getDb();
      const d = await db.query.devis.findFirst({
        where: eq(devis.id, input.id),
        with: { worker: true, client: true, items: true, booking: true },
      });
      if (!d || (d.workerId !== ctx.user.id && d.clientId !== ctx.user.id)) throw new Error("Not authorized");
      return d;
    }),

  updateDevisStatus: authedQuery
    .input(z.object({ id: z.number(), status: z.enum(["draft", "sent", "accepted", "rejected", "expired"]) }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const d = await db.query.devis.findFirst({ where: eq(devis.id, input.id) });
      if (!d || (d.workerId !== ctx.user.id && d.clientId !== ctx.user.id)) throw new Error("Not authorized");
      await db.update(devis).set({ status: input.status }).where(eq(devis.id, input.id));
      return { success: true };
    }),
});
