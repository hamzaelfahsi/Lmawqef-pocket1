import { eq, and, desc, sql } from "drizzle-orm";
import { z } from "zod";
import { createRouter, publicQuery, authedQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { users, levels, badges, userBadges, portfolioItems, availabilities, notifications } from "@db/schema";

export const userRouter = createRouter({
  me: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const user = await db.query.users.findFirst({
      where: eq(users.id, ctx.user.id),
      with: { level: true, subscriptionPlan: true },
    });
    return user;
  }),

  updateProfile: authedQuery
    .input(
      z.object({
        name: z.string().min(2).max(255).optional(),
        phone: z.string().max(50).optional(),
        city: z.string().max(100).optional(),
        bio: z.string().max(2000).optional(),
        address: z.string().max(500).optional(),
        profession: z.string().max(255).optional(),
        latitude: z.string().optional(),
        longitude: z.string().optional(),
        avatar: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      await db.update(users).set({
        ...input,
        updatedAt: new Date(),
      }).where(eq(users.id, ctx.user.id));
      return { success: true };
    }),

  setupWorkerProfile: authedQuery
    .input(
      z.object({
        accountType: z.enum(["worker", "enterprise", "auto_entrepreneur", "freelance"]),
        profession: z.string().min(2).max(255),
        bio: z.string().max(2000).optional(),
        city: z.string().min(1).max(100),
        phone: z.string().min(8).max(50),
        address: z.string().max(500).optional(),
        enterpriseName: z.string().max(255).optional(),
        iceNumber: z.string().max(50).optional(),
        rcNumber: z.string().max(50).optional(),
        latitude: z.string().optional(),
        longitude: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      await db.update(users).set({
        ...input,
        updatedAt: new Date(),
      }).where(eq(users.id, ctx.user.id));
      return { success: true };
    }),

  getProfile: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const user = await db.query.users.findFirst({
        where: eq(users.id, input.id),
        with: { level: true, portfolioItems: true, userBadges: { with: { badge: true } } },
      });
      return user;
    }),

  listWorkers: publicQuery
    .input(
      z.object({
        city: z.string().optional(),
        profession: z.string().optional(),
        categoryId: z.number().optional(),
        isFeatured: z.boolean().optional(),
        limit: z.number().default(20),
        offset: z.number().default(0),
      })
    )
    .query(async ({ input }) => {
      const db = getDb();
      const conditions = [sql`${users.accountType} IN ('worker', 'enterprise', 'auto_entrepreneur', 'freelance')`];
      if (input.city) conditions.push(eq(users.city, input.city));
      if (input.profession) conditions.push(sql`${users.profession} LIKE ${`%${input.profession}%`}`);
      if (input.isFeatured !== undefined) conditions.push(eq(users.isFeatured, input.isFeatured));

      const list = await db.query.users.findMany({
        where: and(...conditions),
        limit: input.limit,
        offset: input.offset,
        orderBy: [desc(users.rating), desc(users.completedJobs)],
        with: { level: true },
      });
      return list;
    }),

  // Portfolio
  addPortfolioItem: authedQuery
    .input(z.object({ title: z.string().min(1), description: z.string().optional(), imageUrl: z.string().min(1) }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const item = await db.insert(portfolioItems).values({ userId: ctx.user.id, ...input });
      return item;
    }),

  removePortfolioItem: authedQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      await db.delete(portfolioItems).where(and(eq(portfolioItems.id, input.id), eq(portfolioItems.userId, ctx.user.id)));
      return { success: true };
    }),

  // Availability
  getAvailability: publicQuery
    .input(z.object({ userId: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      return db.query.availabilities.findMany({
        where: eq(availabilities.userId, input.userId),
        orderBy: availabilities.dayOfWeek,
      });
    }),

  setAvailability: authedQuery
    .input(z.object({ slots: z.array(z.object({ dayOfWeek: z.number().min(0).max(6), startTime: z.string(), endTime: z.string(), isAvailable: z.boolean() })) }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      await db.delete(availabilities).where(eq(availabilities.userId, ctx.user.id));
      if (input.slots.length > 0) {
        await db.insert(availabilities).values(input.slots.map(s => ({ userId: ctx.user.id, ...s })));
      }
      return { success: true };
    }),

  // Notifications
  getNotifications: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    return db.query.notifications.findMany({
      where: eq(notifications.userId, ctx.user.id),
      orderBy: desc(notifications.createdAt),
      limit: 50,
    });
  }),

  markNotificationRead: authedQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      await db.update(notifications).set({ isRead: true }).where(and(eq(notifications.id, input.id), eq(notifications.userId, ctx.user.id)));
      return { success: true };
    }),

  markAllNotificationsRead: authedQuery.mutation(async ({ ctx }) => {
    const db = getDb();
    await db.update(notifications).set({ isRead: true }).where(eq(notifications.userId, ctx.user.id));
    return { success: true };
  }),

  // Gamification
  getLeaderboard: publicQuery
    .input(z.object({ limit: z.number().default(20) }))
    .query(async ({ input }) => {
      const db = getDb();
      return db.query.users.findMany({
        where: sql`${users.accountType} IN ('worker', 'enterprise', 'auto_entrepreneur', 'freelance')`,
        orderBy: [desc(users.points)],
        limit: input.limit,
        with: { level: true },
      });
    }),

  getUserBadges: publicQuery
    .input(z.object({ userId: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      return db.query.userBadges.findMany({
        where: eq(userBadges.userId, input.userId),
        with: { badge: true },
      });
    }),

  getAllBadges: publicQuery.query(async () => {
    const db = getDb();
    return db.query.badges.findMany({ orderBy: badges.createdAt });
  }),

  getAllLevels: publicQuery.query(async () => {
    const db = getDb();
    return db.query.levels.findMany({ orderBy: levels.minPoints });
  }),
});
