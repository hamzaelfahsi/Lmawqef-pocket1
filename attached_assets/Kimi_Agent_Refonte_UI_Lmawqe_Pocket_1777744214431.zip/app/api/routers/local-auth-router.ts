import bcrypt from "bcryptjs";
import * as jose from "jose";
import * as cookie from "cookie";
import { eq } from "drizzle-orm";
import { z } from "zod";
import { createRouter, publicQuery, authedQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { users } from "@db/schema";
import type { User } from "@db/schema";
import { env } from "../lib/env";
import { getSessionCookieOptions } from "../lib/cookies";

const LOCAL_SESSION_COOKIE = "local_session";
const JWT_ALG = "HS256";

async function signLocalToken(userId: number): Promise<string> {
  const secret = new TextEncoder().encode(env.appSecret);
  return new jose.SignJWT({ userId, type: "local" })
    .setProtectedHeader({ alg: JWT_ALG })
    .setIssuedAt()
    .setExpirationTime("30d")
    .sign(secret);
}

async function verifyLocalToken(token: string): Promise<{ userId: number } | null> {
  try {
    const secret = new TextEncoder().encode(env.appSecret);
    const { payload } = await jose.jwtVerify(token, secret, { algorithms: [JWT_ALG] });
    if (payload.type !== "local" || !payload.userId) return null;
    return { userId: payload.userId as number };
  } catch {
    return null;
  }
}

export async function authenticateLocalRequest(headers: Headers): Promise<User | undefined> {
  const cookies = cookie.parse(headers.get("cookie") || "");
  const token = cookies[LOCAL_SESSION_COOKIE];
  if (!token) return undefined;
  const claim = await verifyLocalToken(token);
  if (!claim) return undefined;
  const db = getDb();
  const user = await db.query.users.findFirst({ where: eq(users.id, claim.userId) });
  return user || undefined;
}

export const localAuthRouter = createRouter({
  register: publicQuery
    .input(z.object({
      name: z.string().min(2).max(255),
      email: z.string().email().max(320),
      password: z.string().min(6).max(255),
      phone: z.string().max(50).optional(),
      city: z.string().max(100).optional(),
      accountType: z.enum(["client", "worker", "enterprise", "auto_entrepreneur", "freelance"]).default("client"),
      profession: z.string().max(255).optional(),
    }))
    .mutation(async ({ input, ctx }) => {
      const db = getDb();
      const existing = await db.query.users.findFirst({ where: eq(users.email, input.email) });
      if (existing) throw new Error("Email déjà utilisé");
      const passwordHash = await bcrypt.hash(input.password, 10);
      const [user] = await db.insert(users).values({
        email: input.email,
        passwordHash,
        name: input.name,
        phone: input.phone,
        city: input.city,
        accountType: input.accountType,
        profession: input.profession,
      }).$returningId();
      const token = await signLocalToken(user.id);
      const opts = getSessionCookieOptions(ctx.req.headers);
      ctx.resHeaders.append("set-cookie", cookie.serialize(LOCAL_SESSION_COOKIE, token, {
        httpOnly: opts.httpOnly,
        path: opts.path,
        sameSite: opts.sameSite?.toLowerCase() as "lax" | "none",
        secure: opts.secure,
        maxAge: 30 * 24 * 60 * 60,
      }));
      return { id: user.id, email: input.email, name: input.name };
    }),

  login: publicQuery
    .input(z.object({ email: z.string().email(), password: z.string() }))
    .mutation(async ({ input, ctx }) => {
      const db = getDb();
      const user = await db.query.users.findFirst({ where: eq(users.email, input.email) });
      if (!user || !user.passwordHash) throw new Error("Email ou mot de passe incorrect");
      const valid = await bcrypt.compare(input.password, user.passwordHash);
      if (!valid) throw new Error("Email ou mot de passe incorrect");
      const token = await signLocalToken(user.id);
      const opts = getSessionCookieOptions(ctx.req.headers);
      ctx.resHeaders.append("set-cookie", cookie.serialize(LOCAL_SESSION_COOKIE, token, {
        httpOnly: opts.httpOnly,
        path: opts.path,
        sameSite: opts.sameSite?.toLowerCase() as "lax" | "none",
        secure: opts.secure,
        maxAge: 30 * 24 * 60 * 60,
      }));
      return { id: user.id, email: user.email, name: user.name, role: user.role };
    }),

  logout: authedQuery.mutation(async ({ ctx }) => {
    const opts = getSessionCookieOptions(ctx.req.headers);
    ctx.resHeaders.append("set-cookie", cookie.serialize(LOCAL_SESSION_COOKIE, "", {
      httpOnly: opts.httpOnly,
      path: opts.path,
      sameSite: opts.sameSite?.toLowerCase() as "lax" | "none",
      secure: opts.secure,
      maxAge: 0,
    }));
    return { success: true };
  }),
});
