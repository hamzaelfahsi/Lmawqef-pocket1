import { useNavigate } from "react-router";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { 
  Star, Calendar, MessageSquare, DollarSign, Award, Shield, Crown,
  Plus, TrendingUp, Package, Zap
} from "lucide-react";

export default function Dashboard() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { data: profile } = trpc.user.me.useQuery();
  const { data: bookings } = trpc.service.listMyBookings.useQuery();
  const { data: allServices } = trpc.service.listServices.useQuery({ limit: 50 });
  const services = allServices?.filter((s) => s.workerId === user?.id);

  const isWorker = profile?.accountType !== "client";

  const stats = [
    { label: "Réservations", value: bookings?.asClient?.length || 0, icon: Calendar },
    { label: "Messages", value: 0, icon: MessageSquare },
    { label: "Points", value: profile?.points || 0, icon: Award },
    ...(isWorker ? [
      { label: "Services", value: services?.length || 0, icon: Package },
      { label: "Missions", value: bookings?.asWorker?.length || 0, icon: TrendingUp },
      { label: "Revenus", value: "0 MAD", icon: DollarSign },
    ] : []),
  ];

  return (
    <div className="container py-8">
      <h1 className="text-3xl font-bold mb-2">Tableau de bord</h1>
      <p className="text-slate-500 mb-8">Bienvenue, {profile?.name || "Utilisateur"}</p>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-8">
        {stats.map((s) => (
          <Card key={s.label}>
            <CardContent className="p-4">
              <s.icon className="w-5 h-5 text-[#0D9488] mb-2" />
              <div className="text-2xl font-bold">{s.value}</div>
              <div className="text-xs text-slate-500">{s.label}</div>
            </CardContent>
          </Card>
        ))}
      </div>

      {profile?.level && (
        <Card className="mb-8 border-l-4" style={{ borderLeftColor: profile.level.color }}>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="w-12 h-12 rounded-full flex items-center justify-center text-white" style={{ backgroundColor: profile.level.color }}>
              <Award className="w-6 h-6" />
            </div>
            <div>
              <div className="font-semibold">Niveau {profile.level.name}</div>
              <div className="text-sm text-slate-500">{profile.points} points • {profile.level.minPoints} - {profile.level.maxPoints} pts</div>
            </div>
            {profile.isFeatured && <Badge className="ml-auto bg-amber-500 text-white"><Crown className="w-3 h-3 mr-1" /> En vedette</Badge>}
            {profile.hasInsurance && <Badge className="ml-auto bg-green-500 text-white"><Shield className="w-3 h-3 mr-1" /> Assuré</Badge>}
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <Tabs defaultValue="bookings">
            <TabsList className="bg-slate-100">
              <TabsTrigger value="bookings">Réservations</TabsTrigger>
              {isWorker && <TabsTrigger value="services">Mes services</TabsTrigger>}
            </TabsList>
            <TabsContent value="bookings" className="mt-4 space-y-3">
              {(isWorker ? bookings?.asWorker : bookings?.asClient)?.map((b) => (
                <Card key={b.id} className="cursor-pointer hover:shadow-md transition-all" onClick={() => navigate(`/messages?booking=${b.id}`)}>
                  <CardContent className="p-4 flex items-center justify-between">
                    <div>
                      <div className="font-semibold">{b.service?.title}</div>
                      <div className="text-sm text-slate-500">{b.status} • {new Date(b.date).toLocaleDateString("fr-FR")}</div>
                    </div>
                    <div className="text-right">
                      <div className="font-bold">{b.price} MAD</div>
                      {b.rating && <span className="text-xs text-amber-500 flex items-center gap-1"><Star className="w-3 h-3 fill-current" /> {b.rating}</span>}
                    </div>
                  </CardContent>
                </Card>
              )) || <p className="text-slate-500">Aucune réservation.</p>}
            </TabsContent>
            {isWorker && (
              <TabsContent value="services" className="mt-4 space-y-3">
                {services?.map((s) => (
                  <Card key={s.id} className="cursor-pointer hover:shadow-md transition-all" onClick={() => navigate(`/service/${s.id}`)}>
                    <CardContent className="p-4 flex items-center justify-between">
                      <div>
                        <div className="font-semibold">{s.title}</div>
                        <div className="text-sm text-slate-500">{s.city} • {s.isActive ? "Actif" : "Inactif"}</div>
                      </div>
                      <div className="font-bold">{s.price} MAD</div>
                    </CardContent>
                  </Card>
                )) || <p className="text-slate-500">Aucun service.</p>}
                <Button className="w-full bg-[#0D9488] hover:bg-[#0F766E] text-white" onClick={() => navigate("/marketplace")}>
                  <Plus className="w-4 h-4 mr-2" /> Ajouter un service
                </Button>
              </TabsContent>
            )}
          </Tabs>
        </div>

        <div className="space-y-4">
          <Card>
            <CardHeader className="pb-3"><CardTitle className="text-sm">Actions rapides</CardTitle></CardHeader>
            <CardContent className="space-y-2">
              <Button variant="outline" className="w-full justify-start" onClick={() => navigate("/messages")}><MessageSquare className="w-4 h-4 mr-2" /> Messages</Button>
              <Button variant="outline" className="w-full justify-start" onClick={() => navigate("/notifications")}><DollarSign className="w-4 h-4 mr-2" /> Notifications</Button>
              {isWorker && (
                <Button variant="outline" className="w-full justify-start" onClick={() => navigate("/annonces/new")}><Zap className="w-4 h-4 mr-2" /> Créer une annonce</Button>
              )}
              <Button variant="outline" className="w-full justify-start" onClick={() => navigate("/abonnements")}><Crown className="w-4 h-4 mr-2" /> Abonnements</Button>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-3"><CardTitle className="text-sm">Mon abonnement</CardTitle></CardHeader>
            <CardContent>
              {profile?.subscriptionPlan ? (
                <div>
                  <div className="font-semibold text-[#0D9488]">{profile.subscriptionPlan.name}</div>
                  <div className="text-sm text-slate-500">Expire le {profile.subscriptionUntil ? new Date(profile.subscriptionUntil).toLocaleDateString("fr-FR") : "N/A"}</div>
                </div>
              ) : (
                <div className="text-sm text-slate-500">Aucun abonnement actif</div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
