import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { 
  Users, DollarSign, Package, Shield, 
  TrendingUp, MessageSquare, Wrench
} from "lucide-react";

export default function Admin() {
  const { user } = useAuth();
  const [search, setSearch] = useState("");
  const { data: stats } = trpc.admin.stats.useQuery(undefined, { enabled: user?.role === "admin" || user?.role === "superadmin" });
  const { data: allUsers } = trpc.admin.listUsers.useQuery({ search, limit: 50 }, { enabled: user?.role === "admin" || user?.role === "superadmin" });
  const { data: allPayments } = trpc.payment.listAllPayments.useQuery(undefined, { enabled: user?.role === "admin" || user?.role === "superadmin" });
  const { data: allCommissions } = trpc.admin.listCommissions.useQuery(undefined, { enabled: user?.role === "admin" || user?.role === "superadmin" });
  const { data: contactMessages } = trpc.admin.listContactMessages.useQuery(undefined, { enabled: user?.role === "admin" || user?.role === "superadmin" });
  const utils = trpc.useUtils();
  const seedMutation = trpc.admin.seedDefaults.useMutation({ onSuccess: () => utils.invalidate() });

  if (user?.role !== "admin" && user?.role !== "superadmin") {
    return <div className="container py-20 text-center text-red-500">Accès interdit</div>;
  }

  return (
    <div className="container py-8">
      <h1 className="text-3xl font-bold mb-8">Panel Admin</h1>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        {[
          { label: "Utilisateurs", value: stats?.counts.users || 0, icon: Users, color: "#0D9488" },
          { label: "Professionnels", value: stats?.counts.workers || 0, icon: Wrench, color: "#3b82f6" },
          { label: "Services", value: stats?.counts.services || 0, icon: Package, color: "#f59e0b" },
          { label: "Réservations", value: stats?.counts.bookings || 0, icon: TrendingUp, color: "#8b5cf6" },
          { label: "Revenus (MAD)", value: stats?.revenue || 0, icon: DollarSign, color: "#10b981" },
          { label: "Commissions", value: stats?.pendingCommission || 0, icon: DollarSign, color: "#ec4899" },
          { label: "Messages contact", value: stats?.contactUnread || 0, icon: MessageSquare, color: "#ef4444" },
        ].map((s) => (
          <Card key={s.label}>
            <CardContent className="p-4">
              <s.icon className="w-5 h-5 mb-2" style={{ color: s.color }} />
              <div className="text-2xl font-bold">{s.value}</div>
              <div className="text-xs text-slate-500">{s.label}</div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Button className="mb-8 bg-[#0D9488] hover:bg-[#0F766E] text-white" onClick={() => seedMutation.mutate()}>
        <Wrench className="w-4 h-4 mr-2" /> Initialiser données (badges, niveaux, catégories)
      </Button>

      <Tabs defaultValue="users">
        <TabsList className="bg-slate-100">
          <TabsTrigger value="users">Utilisateurs</TabsTrigger>
          <TabsTrigger value="payments">Paiements</TabsTrigger>
          <TabsTrigger value="commissions">Commissions</TabsTrigger>
          <TabsTrigger value="contacts">Messages</TabsTrigger>
        </TabsList>
        <TabsContent value="users" className="mt-4">
          <Input placeholder="Rechercher..." className="mb-4" value={search} onChange={(e) => setSearch(e.target.value)} />
          <div className="space-y-2">
            {allUsers?.map((u) => (
              <Card key={u.id}>
                <CardContent className="p-4 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-slate-200 flex items-center justify-center text-sm font-bold">{u.name?.charAt(0) || "?"}</div>
                    <div>
                      <div className="font-medium">{u.name || "Sans nom"} <span className="text-xs text-slate-400">({u.email})</span></div>
                      <div className="text-xs text-slate-500">{u.accountType} • {u.city}</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant={u.role === "admin" || u.role === "superadmin" ? "default" : "secondary"}>{u.role}</Badge>
                    {u.isVerified && <Badge className="bg-[#0D9488] text-white"><Shield className="w-3 h-3 mr-1" /> Vérifié</Badge>}
                  </div>
                </CardContent>
              </Card>
            )) || <p className="text-slate-500">Aucun utilisateur.</p>}
          </div>
        </TabsContent>
        <TabsContent value="payments" className="mt-4">
          <div className="space-y-2">
            {allPayments?.map((p: any) => (
              <Card key={p.id}>
                <CardContent className="p-4 flex items-center justify-between">
                  <div>
                    <div className="font-medium">{p.type} • {p.amount} {p.currency}</div>
                    <div className="text-xs text-slate-500">{p.user?.name} • {p.paymentMethod}</div>
                  </div>
                  <Badge className={p.status === "completed" ? "bg-green-500 text-white" : p.status === "pending" ? "bg-amber-500 text-white" : "bg-red-500 text-white"}>{p.status}</Badge>
                </CardContent>
              </Card>
            )) || <p className="text-slate-500">Aucun paiement.</p>}
          </div>
        </TabsContent>
        <TabsContent value="commissions" className="mt-4">
          <div className="space-y-2">
            {allCommissions?.map((c) => (
              <Card key={c.id}>
                <CardContent className="p-4 flex items-center justify-between">
                  <div>
                    <div className="font-medium">{c.amount} MAD ({c.rate}%)</div>
                    <div className="text-xs text-slate-500">{c.worker?.name} • Booking #{c.bookingId}</div>
                  </div>
                  <Badge className={c.status === "paid" ? "bg-green-500 text-white" : "bg-amber-500 text-white"}>{c.status}</Badge>
                </CardContent>
              </Card>
            )) || <p className="text-slate-500">Aucune commission.</p>}
          </div>
        </TabsContent>
        <TabsContent value="contacts" className="mt-4">
          <div className="space-y-2">
            {contactMessages?.map((m) => (
              <Card key={m.id}>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-medium">{m.name}</span>
                    {!m.isRead && <Badge variant="outline">Non lu</Badge>}
                  </div>
                  <div className="text-sm text-slate-600">{m.subject}</div>
                  <div className="text-sm text-slate-500 mt-1">{m.message}</div>
                  <div className="text-xs text-slate-400 mt-2">{m.email} • {new Date(m.createdAt).toLocaleString("fr-FR")}</div>
                </CardContent>
              </Card>
            )) || <p className="text-slate-500">Aucun message.</p>}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
