import { useState } from "react";
import { useParams, useNavigate } from "react-router";
import { trpc } from "@/providers/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useAuth } from "@/hooks/useAuth";
import { Star, MapPin, Calendar, MessageSquare, Shield, Zap, ArrowLeft } from "lucide-react";

export default function ServiceDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { isAuthenticated } = useAuth();
  const [bookingDate, setBookingDate] = useState("");
  const [bookingNotes, setBookingNotes] = useState("");
  const [openBooking, setOpenBooking] = useState(false);

  const { data: service } = trpc.service.getService.useQuery({ id: Number(id) });
  const utils = trpc.useUtils();
  const bookingMutation = trpc.service.createBooking.useMutation({
    onSuccess: () => {
      setOpenBooking(false);
      utils.service.listMyBookings.invalidate();
      navigate("/dashboard");
    },
  });

  if (!service) return <div className="container py-20 text-center">Chargement...</div>;

  const price = parseFloat(service.price.toString());
  const finalPrice = service.isUrgent ? price * parseFloat(service.urgentMultiplier.toString()) : price;

  return (
    <div className="container py-8">
      <button onClick={() => navigate(-1)} className="flex items-center gap-2 text-sm text-slate-500 hover:text-slate-900 mb-6">
        <ArrowLeft className="w-4 h-4" /> Retour
      </button>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <div className="grid grid-cols-2 gap-3 mb-6">
            {service.images?.length > 0 ? (
              service.images.map((img, i) => (
                <div key={i} className={`rounded-xl overflow-hidden bg-slate-200 ${i === 0 ? "col-span-2 h-64" : "h-40"}`}>
                  <img src={img.imageUrl} alt="" className="w-full h-full object-cover" />
                </div>
              ))
            ) : (
              <div className="col-span-2 h-64 rounded-xl bg-slate-100 flex items-center justify-center text-slate-400">Pas d'images</div>
            )}
          </div>
          <h1 className="text-3xl font-bold mb-2">{service.title}</h1>
          <div className="flex items-center gap-4 text-sm text-slate-500 mb-6">
            <span className="flex items-center gap-1"><MapPin className="w-4 h-4" /> {service.city}</span>
            <span className="bg-teal-50 text-[#0D9488] px-2 py-1 rounded font-medium">{service.category?.name}</span>
            {service.isUrgent && <span className="bg-red-50 text-red-600 px-2 py-1 rounded font-medium flex items-center gap-1"><Zap className="w-3 h-3" /> Urgent</span>}
          </div>
          <p className="text-slate-700 whitespace-pre-line mb-8">{service.description}</p>
        </div>

        <div>
          <Card className="sticky top-24">
            <CardContent className="p-6">
              <div className="text-center mb-6">
                <div className="text-3xl font-bold text-slate-900">{finalPrice.toFixed(2)} MAD</div>
                <div className="text-sm text-slate-500">{service.priceType === "hourly" ? "par heure" : service.priceType === "quote" ? "sur devis" : "prix fixe"}</div>
                {service.isUrgent && (
                  <div className="text-xs text-red-500 mt-1">Multiplicateur urgence x{service.urgentMultiplier}</div>
                )}
              </div>
              <div className="space-y-3">
                <Button className="w-full bg-[#0D9488] hover:bg-[#0F766E] text-white" onClick={() => { if (!isAuthenticated) { navigate("/login"); return; } setOpenBooking(true); }}>
                  <Calendar className="w-4 h-4 mr-2" /> Réserver
                </Button>
                <Button variant="outline" className="w-full" onClick={() => navigate(`/worker/${service.workerId}`)}>
                  <MessageSquare className="w-4 h-4 mr-2" /> Contacter
                </Button>
              </div>
              <div className="mt-6 pt-6 border-t">
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-10 h-10 rounded-full bg-slate-200 flex items-center justify-center font-bold text-sm">
                    {service.worker?.name?.charAt(0) || "?"}
                  </div>
                  <div>
                    <div className="font-semibold">{service.worker?.name}</div>
                    <div className="text-xs text-slate-500">{service.worker?.profession}</div>
                  </div>
                </div>
                {service.worker?.rating && (
                  <div className="flex items-center gap-1 text-sm text-amber-500">
                    <Star className="w-4 h-4 fill-current" /> {service.worker.rating} ({service.worker.reviewCount} avis)
                  </div>
                )}
                {service.worker?.isVerified && (
                  <div className="flex items-center gap-1 text-xs text-[#0D9488] mt-2">
                    <Shield className="w-3 h-3" /> Profil vérifié
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <Dialog open={openBooking} onOpenChange={setOpenBooking}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Réserver ce service</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 mt-4">
            <div>
              <Label>Date du service</Label>
              <Input type="datetime-local" value={bookingDate} onChange={(e) => setBookingDate(e.target.value)} />
            </div>
            <div>
              <Label>Notes</Label>
              <Textarea placeholder="Détails supplémentaires..." value={bookingNotes} onChange={(e) => setBookingNotes(e.target.value)} />
            </div>
            <Button className="w-full bg-[#0D9488] hover:bg-[#0F766E] text-white" disabled={!bookingDate || bookingMutation.isPending} onClick={() => bookingMutation.mutate({ serviceId: service.id, workerId: service.workerId, date: bookingDate, notes: bookingNotes })}>
              {bookingMutation.isPending ? "Réservation..." : "Confirmer la réservation"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
