import { trpc } from "@/providers/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Bell, Calendar, MessageSquare, Star, DollarSign, Award, Check } from "lucide-react";

const typeConfig: Record<string, { icon: any; color: string; label: string }> = {
  booking: { icon: Calendar, color: "#0D9488", label: "Réservation" },
  message: { icon: MessageSquare, color: "#3b82f6", label: "Message" },
  review: { icon: Star, color: "#f59e0b", label: "Avis" },
  payment: { icon: DollarSign, color: "#10b981", label: "Paiement" },
  subscription: { icon: Award, color: "#8b5cf6", label: "Abonnement" },
  badge: { icon: Award, color: "#ec4899", label: "Badge" },
  system: { icon: Bell, color: "#64748b", label: "Système" },
};

export default function NotificationsPage() {
  const { data: notifications, refetch } = trpc.user.getNotifications.useQuery();
  const markRead = trpc.user.markNotificationRead.useMutation({ onSuccess: () => refetch() });
  const markAll = trpc.user.markAllNotificationsRead.useMutation({ onSuccess: () => refetch() });

  return (
    <div className="container py-8 max-w-2xl">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-3xl font-bold">Notifications</h1>
        <Button variant="outline" size="sm" onClick={() => markAll.mutate()}>
          <Check className="w-4 h-4 mr-2" /> Tout marquer comme lu
        </Button>
      </div>
      <div className="space-y-3">
        {notifications?.map((n) => {
          const config = typeConfig[n.type] || typeConfig.system;
          const Icon = config.icon;
          return (
            <Card key={n.id} className={`cursor-pointer hover:shadow-md transition-all ${!n.isRead ? "border-l-4 border-l-[#0D9488]" : ""}`} onClick={() => { if (!n.isRead) markRead.mutate({ id: n.id }); }}>
              <CardContent className="p-4 flex items-start gap-3">
                <div className="w-10 h-10 rounded-lg flex items-center justify-center shrink-0" style={{ backgroundColor: config.color + "20", color: config.color }}>
                  <Icon className="w-5 h-5" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-sm">{n.title}</span>
                    {!n.isRead && <span className="w-2 h-2 rounded-full bg-[#0D9488]" />}
                  </div>
                  <p className="text-sm text-slate-500 mt-1">{n.content}</p>
                  <div className="text-xs text-slate-400 mt-2">{new Date(n.createdAt).toLocaleString("fr-FR")}</div>
                </div>
              </CardContent>
            </Card>
          );
        }) || <p className="text-slate-500 text-center py-10">Aucune notification.</p>}
      </div>
    </div>
  );
}
