import { useState } from "react";
import { Link } from "react-router";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { trpc } from "@/providers/trpc";
import { Mail, Lock, User, Phone, MapPin, Eye, EyeOff, Briefcase, Building2, HardHat } from "lucide-react";

export default function Register() {
  const [form, setForm] = useState({
    name: "", email: "", password: "", phone: "", city: "",
    accountType: "client" as const, profession: "",
  });
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const registerMutation = trpc.localAuth.register.useMutation({
    onSuccess: () => { window.location.href = "/"; },
    onError: (err) => setError(err.message),
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    registerMutation.mutate(form);
  };

  const isWorker = form.accountType !== "client";

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-teal-50 to-slate-100 px-4 py-8">
      <Card className="w-full max-w-lg shadow-xl border-0">
        <CardHeader className="text-center pb-2">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#0D9488] to-[#14B8A6] flex items-center justify-center text-white text-lg font-bold mx-auto mb-4">L</div>
          <CardTitle className="text-2xl">Créer un compte</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label>Type de compte</Label>
              <Select value={form.accountType} onValueChange={(v) => setForm({ ...form, accountType: v as any })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="client"><span className="flex items-center gap-2"><User className="w-4 h-4" /> Client</span></SelectItem>
                  <SelectItem value="worker"><span className="flex items-center gap-2"><HardHat className="w-4 h-4" /> Artisan / Prestataire</span></SelectItem>
                  <SelectItem value="enterprise"><span className="flex items-center gap-2"><Building2 className="w-4 h-4" /> Entreprise</span></SelectItem>
                  <SelectItem value="auto_entrepreneur"><span className="flex items-center gap-2"><Briefcase className="w-4 h-4" /> Auto-entrepreneur</span></SelectItem>
                  <SelectItem value="freelance"><span className="flex items-center gap-2"><Briefcase className="w-4 h-4" /> Freelance</span></SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Nom complet</Label>
                <div className="relative">
                  <User className="absolute left-3 top-2.5 w-5 h-5 text-slate-400" />
                  <Input className="pl-10" placeholder="Votre nom" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
                </div>
              </div>
              <div className="space-y-2">
                <Label>Téléphone</Label>
                <div className="relative">
                  <Phone className="absolute left-3 top-2.5 w-5 h-5 text-slate-400" />
                  <Input className="pl-10" placeholder="+212..." value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <Label>Email</Label>
              <div className="relative">
                <Mail className="absolute left-3 top-2.5 w-5 h-5 text-slate-400" />
                <Input type="email" className="pl-10" placeholder="votre@email.com" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} required />
              </div>
            </div>

            <div className="space-y-2">
              <Label>Mot de passe</Label>
              <div className="relative">
                <Lock className="absolute left-3 top-2.5 w-5 h-5 text-slate-400" />
                <Input type={showPassword ? "text" : "password"} className="pl-10 pr-10" placeholder="••••••••" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} required />
                <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-2.5 text-slate-400">
                  {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Ville</Label>
                <div className="relative">
                  <MapPin className="absolute left-3 top-2.5 w-5 h-5 text-slate-400" />
                  <Input className="pl-10" placeholder="Casablanca" value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} />
                </div>
              </div>
              {isWorker && (
                <div className="space-y-2">
                  <Label>Profession</Label>
                  <Input placeholder="Ex: Plombier" value={form.profession} onChange={(e) => setForm({ ...form, profession: e.target.value })} />
                </div>
              )}
            </div>

            {error && <div className="text-sm text-red-500 bg-red-50 p-2 rounded">{error}</div>}
            <Button type="submit" className="w-full bg-[#0D9488] hover:bg-[#0F766E] text-white" disabled={registerMutation.isPending}>
              {registerMutation.isPending ? "Inscription..." : "S'inscrire"}
            </Button>
          </form>
          <div className="mt-6 text-center text-sm text-slate-500">
            Déjà inscrit ? <Link to="/login" className="text-[#0D9488] font-medium hover:underline">Connectez-vous</Link>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
