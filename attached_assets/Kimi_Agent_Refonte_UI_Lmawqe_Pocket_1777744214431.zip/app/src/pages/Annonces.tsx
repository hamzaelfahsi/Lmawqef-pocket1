import { useNavigate } from "react-router";
import { trpc } from "@/providers/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useAuth } from "@/hooks/useAuth";
import { Plus, MapPin, Zap, DollarSign } from "lucide-react";

export default function Annonces() {
  const navigate = useNavigate();
  const { isAuthenticated } = useAuth();
  const { data: annonces } = trpc.annonce.listAnnonces.useQuery({ limit: 50 });
  const { data: myAnnonces } = trpc.annonce.listMyAnnonces.useQuery(undefined, { enabled: isAuthenticated });

  return (
    <div className="container py-8">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-3xl font-bold">Annonces</h1>
        <Button className="bg-[#0D9488] hover:bg-[#0F766E] text-white" onClick={() => navigate("/annonces/new")}>
          <Plus className="w-4 h-4 mr-2" /> Publier une annonce
        </Button>
      </div>

      {myAnnonces && myAnnonces.length > 0 && (
        <div className="mb-8">
          <h2 className="text-lg font-semibold mb-4">Mes annonces</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {myAnnonces.map((a) => (
              <Card key={a.id}>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className={`text-xs font-bold px-2 py-1 rounded ${a.status === "active" ? "bg-green-100 text-green-700" : a.status === "pending" ? "bg-amber-100 text-amber-700" : "bg-slate-100 text-slate-600"}`}>{a.status}</span>
                    {!a.isPaid && <span className="text-xs text-red-500 font-medium">Non payée</span>}
                  </div>
                  <h3 className="font-semibold">{a.title}</h3>
                  <p className="text-sm text-slate-500 line-clamp-2">{a.description}</p>
                  <div className="flex items-center gap-3 mt-3 text-xs text-slate-400">
                    <span className="flex items-center gap-1"><MapPin className="w-3 h-3" /> {a.city}</span>
                    {a.budget && <span className="flex items-center gap-1"><DollarSign className="w-3 h-3" /> {a.budget} MAD</span>}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      <h2 className="text-lg font-semibold mb-4">Toutes les annonces</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {annonces?.map((a) => (
          <Card key={a.id} className="hover:shadow-lg transition-all cursor-pointer" onClick={() => navigate(`/annonces/${a.id}`)}>
            <CardContent className="p-4">
              {a.isUrgent && <span className="inline-flex items-center gap-1 text-xs font-bold text-red-500 mb-2"><Zap className="w-3 h-3" /> URGENT</span>}
              <h3 className="font-semibold mb-1">{a.title}</h3>
              <p className="text-sm text-slate-500 line-clamp-2">{a.description}</p>
              <div className="flex items-center gap-3 mt-3 text-xs text-slate-400">
                <span className="flex items-center gap-1"><MapPin className="w-3 h-3" /> {a.city}</span>
                <span>{a.views} vues</span>
              </div>
            </CardContent>
          </Card>
        )) || <p className="text-slate-500">Aucune annonce pour le moment.</p>}
      </div>
    </div>
  );
}
