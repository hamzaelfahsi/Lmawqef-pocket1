import { Link, useNavigate } from "react-router";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { trpc } from "@/providers/trpc";
import {
  Search, Star, Shield, Zap, MessageSquare, Award,
  ArrowRight, Droplet, Zap as ZapIcon, Trees, Paintbrush, Leaf,
  Sparkles, Truck, Laptop, Wind, HardHat, Crown
} from "lucide-react";

const categoryIcons: Record<string, any> = {
  plomberie: Droplet,
  electricite: ZapIcon,
  menuiserie: Trees,
  peinture: Paintbrush,
  jardinage: Leaf,
  nettoyage: Sparkles,
  demenagement: Truck,
  informatique: Laptop,
  climatisation: Wind,
  construction: HardHat,
};

export default function Home() {
  const navigate = useNavigate();
  const { data: categories } = trpc.service.listCategories.useQuery();
  const { data: featuredWorkers } = trpc.user.listWorkers.useQuery({ isFeatured: true, limit: 6 });
  const { data: recentServices } = trpc.service.listServices.useQuery({ limit: 6 });

  return (
    <div>
      {/* Hero */}
      <section className="relative overflow-hidden bg-gradient-to-br from-[#0D9488] via-[#14B8A6] to-[#0F766E] text-white">
        <div className="absolute inset-0 opacity-10 bg-[radial-gradient(circle_at_30%_20%,white,transparent_40%)]" />
        <div className="container py-20 md:py-28 relative">
          <div className="max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/20 text-sm font-medium mb-6">
              <Award className="w-4 h-4" /> N°1 des services au Maroc
            </div>
            <h1 className="text-4xl md:text-6xl font-bold leading-tight mb-6">
              Trouvez les meilleurs <span className="text-amber-300">professionnels</span> près de chez vous
            </h1>
            <p className="text-lg md:text-xl text-teal-50 mb-8">
              Plomberie, électricité, menuiserie, jardinage... Réservez en quelques clics et payez en toute sécurité.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button size="lg" className="bg-white text-[#0D9488] hover:bg-teal-50 font-semibold" onClick={() => navigate("/marketplace")}>
                <Search className="w-5 h-5 mr-2" /> Trouver un service
              </Button>
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/20" onClick={() => navigate("/register")}>
                Devenir prestataire <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </div>
          </div>
          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-12">
            {[
              { label: "Professionnels", value: "2,500+" },
              { label: "Services réalisés", value: "15,000+" },
              { label: "Clients satisfaits", value: "8,000+" },
              { label: "Villes couvertes", value: "30+" },
            ].map((s) => (
              <div key={s.label} className="bg-white/10 backdrop-blur-sm rounded-xl p-4 text-center">
                <div className="text-2xl font-bold">{s.value}</div>
                <div className="text-sm text-teal-100">{s.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="py-16 bg-slate-50">
        <div className="container">
          <h2 className="text-3xl font-bold text-center mb-12 text-slate-900">Nos catégories de services</h2>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            {categories?.map((cat) => {
              const Icon = categoryIcons[cat.slug] || ZapIcon;
              return (
                <Card key={cat.id} className="cursor-pointer hover:shadow-lg transition-all hover:-translate-y-1 border-0 bg-white" onClick={() => navigate(`/marketplace?category=${cat.id}`)}>
                  <CardContent className="p-6 flex flex-col items-center text-center">
                    <div className="w-12 h-12 rounded-xl flex items-center justify-center mb-3" style={{ backgroundColor: (cat.color || "#0D9488") + "20", color: cat.color || "#0D9488" }}>
                      <Icon className="w-6 h-6" />
                    </div>
                    <h3 className="font-semibold text-slate-900">{cat.name}</h3>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Featured Workers */}
      <section className="py-16">
        <div className="container">
          <div className="flex items-center justify-between mb-12">
            <h2 className="text-3xl font-bold text-slate-900">Professionnels en vedette</h2>
            <Link to="/workers" className="text-[#0D9488] font-medium flex items-center gap-1 hover:underline">
              Voir tout <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {featuredWorkers?.map((worker) => (
              <Card key={worker.id} className="overflow-hidden hover:shadow-lg transition-all cursor-pointer" onClick={() => navigate(`/worker/${worker.id}`)}>
                <div className="h-24 bg-gradient-to-r from-[#0D9488] to-[#14B8A6]" />
                <CardContent className="p-6 relative">
                  <div className="absolute -top-8 left-6 w-16 h-16 rounded-full bg-white p-1 shadow-md">
                    {worker.avatar ? (
                      <img src={worker.avatar} alt="" className="w-full h-full rounded-full object-cover" />
                    ) : (
                      <div className="w-full h-full rounded-full bg-slate-200 flex items-center justify-center text-slate-500 text-lg font-bold">
                        {worker.name?.charAt(0) || "?"}
                      </div>
                    )}
                  </div>
                  <div className="mt-8">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="font-bold text-lg">{worker.name}</h3>
                      {worker.isVerified && <Shield className="w-4 h-4 text-[#0D9488]" />}
                      {worker.isFeatured && <Crown className="w-4 h-4 text-amber-500" />}
                    </div>
                    <p className="text-sm text-slate-500 mb-2">{worker.profession} • {worker.city}</p>
                    <div className="flex items-center gap-3 text-sm">
                      <span className="flex items-center gap-1 text-amber-500 font-medium"><Star className="w-4 h-4 fill-current" /> {worker.rating}</span>
                      <span className="text-slate-400">{worker.reviewCount} avis</span>
                      <span className="text-slate-400">{worker.completedJobs} jobs</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Recent Services */}
      <section className="py-16 bg-slate-50">
        <div className="container">
          <div className="flex items-center justify-between mb-12">
            <h2 className="text-3xl font-bold text-slate-900">Services récents</h2>
            <Link to="/marketplace" className="text-[#0D9488] font-medium flex items-center gap-1 hover:underline">
              Voir tout <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {recentServices?.map((service) => (
              <Card key={service.id} className="overflow-hidden hover:shadow-lg transition-all cursor-pointer" onClick={() => navigate(`/service/${service.id}`)}>
                <div className="h-40 bg-slate-200 relative">
                  {service.images?.[0] ? (
                    <img src={service.images[0].imageUrl} alt="" className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center bg-slate-100 text-slate-400">Pas d'image</div>
                  )}
                  {service.isUrgent && (
                    <div className="absolute top-3 left-3 bg-red-500 text-white text-xs font-bold px-2 py-1 rounded-full flex items-center gap-1">
                      <Zap className="w-3 h-3" /> Urgent
                    </div>
                  )}
                </div>
                <CardContent className="p-5">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-medium text-[#0D9488] bg-teal-50 px-2 py-1 rounded">{service.category?.name}</span>
                    <span className="text-xs text-slate-400">{service.city}</span>
                  </div>
                  <h3 className="font-semibold text-slate-900 mb-2 line-clamp-1">{service.title}</h3>
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-lg text-slate-900">{service.price} MAD</span>
                    <span className="text-xs text-slate-500">{service.priceType === "hourly" ? "/heure" : service.priceType === "quote" ? "Sur devis" : ""}</span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* How it works */}
      <section className="py-16">
        <div className="container">
          <h2 className="text-3xl font-bold text-center mb-12 text-slate-900">Comment ça marche ?</h2>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {[
              { icon: Search, title: "Recherchez", desc: "Trouvez le service ou professionnel qu'il vous faut par ville et catégorie." },
              { icon: MessageSquare, title: "Contactez", desc: "Discutez avec le prestataire via le chat intégré et demandez un devis." },
              { icon: Shield, title: "Réservez", desc: "Réservez en toute sécurité avec Lmawqef Protect et le paiement en ligne." },
              { icon: Star, title: "Notez", desc: "Après le service, laissez un avis et gagnez des points de fidélité." },
            ].map((step, i) => (
              <div key={step.title} className="text-center">
                <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-[#0D9488] to-[#14B8A6] flex items-center justify-center mx-auto mb-4 text-white shadow-lg shadow-teal-200">
                  <step.icon className="w-7 h-7" />
                </div>
                <div className="text-sm font-bold text-[#0D9488] mb-2">Étape {i + 1}</div>
                <h3 className="font-bold text-lg mb-2">{step.title}</h3>
                <p className="text-sm text-slate-500">{step.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-gradient-to-r from-slate-900 to-slate-800 text-white">
        <div className="container text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Vous êtes professionnel ?</h2>
          <p className="text-slate-300 max-w-xl mx-auto mb-8">Rejoignez des milliers d'artisans et d'entreprises qui développent leur activité avec Lmawqef Pocket.</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-[#0D9488] hover:bg-[#0F766E] text-white" onClick={() => navigate("/register")}>
              Inscrivez-vous gratuitement
            </Button>
            <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/20" onClick={() => navigate("/abonnements")}>
              Découvrir les abonnements
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}
