import { useNavigate } from "react-router";
import { trpc } from "@/providers/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Check, Crown, Zap, Shield } from "lucide-react";

export default function Subscriptions() {
  const navigate = useNavigate();
  const { data: plans } = trpc.subscription.listPlans.useQuery();
  const { data: mySub } = trpc.subscription.getMySubscription.useQuery();
  const utils = trpc.useUtils();
  const subscribe = trpc.subscription.subscribe.useMutation({
    onSuccess: () => {
      utils.subscription.getMySubscription.invalidate();
      navigate("/dashboard");
    },
  });

  return (
    <div className="container py-8">
      <h1 className="text-3xl font-bold text-center mb-4">Abonnements</h1>
      <p className="text-center text-slate-500 mb-12 max-w-xl mx-auto">Développez votre activité avec nos plans d'abonnement adaptés à chaque profil.</p>

      {mySub && (
        <Card className="mb-8 bg-gradient-to-r from-[#0D9488] to-[#14B8A6] text-white border-0">
          <CardContent className="p-6 flex items-center justify-between">
            <div>
              <div className="font-bold text-lg">Abonnement actif</div>
              <div className="text-teal-100">{mySub.plan?.name} • Expire le {new Date(mySub.expiresAt).toLocaleDateString("fr-FR")}</div>
            </div>
            <Badge className="bg-white text-[#0D9488]"><Crown className="w-3 h-3 mr-1" /> Actif</Badge>
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {plans?.map((plan) => (
          <Card key={plan.id} className={`relative overflow-hidden ${plan.slug === "pro" ? "border-2 border-[#0D9488] shadow-xl" : ""}`}>
            {plan.slug === "pro" && (
              <div className="absolute top-0 right-0 bg-[#0D9488] text-white text-xs font-bold px-3 py-1 rounded-bl-lg">POPULAIRE</div>
            )}
            <CardHeader className="text-center pb-2">
              <CardTitle className="text-xl">{plan.name}</CardTitle>
              <div className="text-3xl font-bold text-slate-900 mt-2">{plan.price} <span className="text-sm font-normal text-slate-500">MAD/mois</span></div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2 text-sm">
                <div className="flex items-center gap-2"><Check className="w-4 h-4 text-[#0D9488]" /> {plan.maxServices} services</div>
                <div className="flex items-center gap-2"><Check className="w-4 h-4 text-[#0D9488]" /> {plan.maxAnnonces} annonces/mois</div>
                <div className="flex items-center gap-2"><Check className="w-4 h-4 text-[#0D9488]" /> {plan.maxPortfolio} images portfolio</div>
              </div>
              <Button className={`w-full ${plan.slug === "pro" ? "bg-[#0D9488] hover:bg-[#0F766E] text-white" : "bg-slate-900 hover:bg-slate-800 text-white"}`} onClick={() => subscribe.mutate({ planId: plan.id })}>
                <Crown className="w-4 h-4 mr-2" /> S'abonner
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="text-center p-6">
          <Shield className="w-10 h-10 text-[#0D9488] mx-auto mb-4" />
          <h3 className="font-bold mb-2">Lmawqef Protect</h3>
          <p className="text-sm text-slate-500 mb-4">Assurance professionnelle pour vos interventions.</p>
          <Button variant="outline" onClick={() => navigate("/insurance")}>En savoir plus</Button>
        </Card>
        <Card className="text-center p-6">
          <Zap className="w-10 h-10 text-amber-500 mx-auto mb-4" />
          <h3 className="font-bold mb-2">Profil en vedette</h3>
          <p className="text-sm text-slate-500 mb-4">Apparaissez en haut des résultats de recherche.</p>
          <Button variant="outline" onClick={() => navigate("/payment?type=featured")}>Activer</Button>
        </Card>
        <Card className="text-center p-6">
          <Crown className="w-10 h-10 text-purple-500 mx-auto mb-4" />
          <h3 className="font-bold mb-2">Annonces sponsorisées</h3>
          <p className="text-sm text-slate-500 mb-4">5 gratuites, puis 20 MAD par annonce.</p>
          <Button variant="outline" onClick={() => navigate("/annonces/new")}>Publier</Button>
        </Card>
      </div>
    </div>
  );
}
