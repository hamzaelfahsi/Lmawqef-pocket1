import { Routes, Route } from 'react-router'
import Layout from './components/Layout'
import Home from './pages/Home'
import Login from './pages/Login'
import Register from './pages/Register'
import NotFound from './pages/NotFound'
import Marketplace from './pages/Marketplace'
import ServiceDetail from './pages/ServiceDetail'
import WorkerProfile from './pages/WorkerProfile'
import Dashboard from './pages/Dashboard'
import Messages from './pages/Messages'
import Notifications from './pages/Notifications'
import Annonces from './pages/Annonces'
import AnnonceCreate from './pages/AnnonceCreate'
import Subscriptions from './pages/Subscriptions'
import Leaderboard from './pages/Leaderboard'
import Admin from './pages/Admin'

export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route path="/" element={<Home />} />
        <Route path="/marketplace" element={<Marketplace />} />
        <Route path="/service/:id" element={<ServiceDetail />} />
        <Route path="/worker/:id" element={<WorkerProfile />} />
        <Route path="/workers" element={<Marketplace />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/messages" element={<Messages />} />
        <Route path="/notifications" element={<Notifications />} />
        <Route path="/annonces" element={<Annonces />} />
        <Route path="/annonces/new" element={<AnnonceCreate />} />
        <Route path="/abonnements" element={<Subscriptions />} />
        <Route path="/leaderboard" element={<Leaderboard />} />
        <Route path="/admin" element={<Admin />} />
      </Route>
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="*" element={<NotFound />} />
    </Routes>
  )
}
