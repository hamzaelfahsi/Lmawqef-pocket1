#!/usr/bin/env python3
"""
Lmawqef Pocket PRO - Moroccan Marketplace Platform
Version PRO avec toutes les fonctionnalites startup
"""

from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify, send_from_directory
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from functools import wraps
from datetime import datetime, timedelta
import os
import json
import random
import string

app = Flask(__name__)
app.config['SECRET_KEY'] = 'lmawqef-pocket-pro-secret-key-2026-v2'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///lmawqef_pro.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['UPLOAD_FOLDER'] = 'static/uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max upload

# Ensure upload directories exist
for subdir in ['profiles', 'services', 'portfolio', 'annonces']:
    os.makedirs(os.path.join(app.config['UPLOAD_FOLDER'], subdir), exist_ok=True)

db = SQLAlchemy(app)

# ==================== DATABASE MODELS ====================

class User(db.Model):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    full_name = db.Column(db.String(100), nullable=False)
    phone = db.Column(db.String(20), nullable=False)
    city = db.Column(db.String(50), nullable=False)
    user_type = db.Column(db.String(20), nullable=False)  # 'client', 'worker', 'entreprise'
    worker_subtype = db.Column(db.String(20), nullable=True)  # 'autoentrepreneur', 'freelance', None
    skills = db.Column(db.Text, nullable=True)
    description = db.Column(db.Text, nullable=True)
    avatar = db.Column(db.String(200), default='default-avatar.png')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_admin = db.Column(db.Boolean, default=False)
    is_active = db.Column(db.Boolean, default=True)
    latitude = db.Column(db.Float, nullable=True)
    longitude = db.Column(db.Float, nullable=True)
    address = db.Column(db.String(300), nullable=True)
    company_name = db.Column(db.String(150), nullable=True)
    rc_number = db.Column(db.String(50), nullable=True)  # Registre de commerce
    ice_number = db.Column(db.String(50), nullable=True)  # ICE Maroc

    # Subscription
    subscription_plan_id = db.Column(db.Integer, db.ForeignKey('subscription_plans.id'), nullable=True)
    subscription_start = db.Column(db.DateTime, nullable=True)
    subscription_end = db.Column(db.DateTime, nullable=True)
    subscription_active = db.Column(db.Boolean, default=False)

    # Annonces counters
    free_announces_used = db.Column(db.Integer, default=0)
    announces_month_used = db.Column(db.Integer, default=0)
    announces_month_reset = db.Column(db.DateTime, default=datetime.utcnow)

    # Relationships
    services = db.relationship('Service', backref='worker', lazy=True, cascade='all, delete-orphan')
    reviews_given = db.relationship('Review', foreign_keys='Review.client_id', backref='client', lazy=True)
    reviews_received = db.relationship('Review', foreign_keys='Review.worker_id', backref='reviewed_worker', lazy=True)
    bookings = db.relationship('Booking', foreign_keys='Booking.client_id', backref='client', lazy=True)
    portfolio_items = db.relationship('PortfolioItem', backref='user', lazy=True, cascade='all, delete-orphan')
    sent_messages = db.relationship('Message', foreign_keys='Message.sender_id', backref='sender', lazy=True)
    received_messages = db.relationship('Message', foreign_keys='Message.receiver_id', backref='receiver', lazy=True)
    notifications = db.relationship('Notification', backref='user', lazy=True, cascade='all, delete-orphan')
    annonces = db.relationship('Annonce', backref='author', lazy=True, cascade='all, delete-orphan')
    payments = db.relationship('Payment', backref='user', lazy=True)

    def average_rating(self):
        reviews = Review.query.filter_by(worker_id=self.id).all()
        if not reviews:
            return 0
        return round(sum(r.rating for r in reviews) / len(reviews), 1)

    def review_count(self):
        return Review.query.filter_by(worker_id=self.id).count()

    def has_active_subscription(self):
        if not self.subscription_active or not self.subscription_end:
            return False
        return datetime.utcnow() < self.subscription_end

    def get_monthly_annonce_limit(self):
        """Returns the number of free annonces this user gets per month"""
        if self.has_active_subscription() and self.subscription_plan:
            return self.subscription_plan.annonce_limit
        # Non-subscribed users get 0 free after initial 5
        return 0

    def get_announce_price(self):
        """Returns price per announce in MAD"""
        config = AppConfig.get()
        if self.has_active_subscription():
            if self.subscription_plan.price == 0:
                return 0  # Free for subscribed
        return config.annonce_price

    def can_post_free_announce(self):
        """New users get 5 free announces"""
        config = AppConfig.get()
        return self.free_announces_used < config.free_announces_new_user

    def can_post_monthly_announce(self):
        """Check monthly quota for subscribers"""
        # Reset counter if new month
        if self.announces_month_reset < datetime.utcnow() - timedelta(days=30):
            self.announces_month_used = 0
            self.announces_month_reset = datetime.utcnow()
            db.session.commit()
        limit = self.get_monthly_annonce_limit()
        return self.announces_month_used < limit and limit > 0


class Service(db.Model):
    __tablename__ = 'services'
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    category = db.Column(db.String(50), nullable=False)
    description = db.Column(db.Text, nullable=False)
    price = db.Column(db.Float, nullable=False)
    city = db.Column(db.String(50), nullable=False)
    worker_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    image = db.Column(db.String(200), default='default-service.jpg')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_active = db.Column(db.Boolean, default=True)
    latitude = db.Column(db.Float, nullable=True)
    longitude = db.Column(db.Float, nullable=True)
    address = db.Column(db.String(300), nullable=True)
    views_count = db.Column(db.Integer, default=0)

    # Relationships
    bookings = db.relationship('Booking', backref='service', lazy=True, cascade='all, delete-orphan')
    images = db.relationship('ServiceImage', backref='service', lazy=True, cascade='all, delete-orphan')


class ServiceImage(db.Model):
    __tablename__ = 'service_images'
    id = db.Column(db.Integer, primary_key=True)
    service_id = db.Column(db.Integer, db.ForeignKey('services.id'), nullable=False)
    filename = db.Column(db.String(200), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class PortfolioItem(db.Model):
    __tablename__ = 'portfolio_items'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=True)
    filename = db.Column(db.String(200), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class Review(db.Model):
    __tablename__ = 'reviews'
    id = db.Column(db.Integer, primary_key=True)
    rating = db.Column(db.Integer, nullable=False)
    comment = db.Column(db.Text, nullable=False)
    client_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    worker_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class Booking(db.Model):
    __tablename__ = 'bookings'
    id = db.Column(db.Integer, primary_key=True)
    client_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    service_id = db.Column(db.Integer, db.ForeignKey('services.id'), nullable=False)
    message = db.Column(db.Text, nullable=False)
    status = db.Column(db.String(20), default='pending')  # pending, accepted, rejected, completed
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow)


class Message(db.Model):
    __tablename__ = 'messages'
    id = db.Column(db.Integer, primary_key=True)
    sender_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    receiver_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    content = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_read = db.Column(db.Boolean, default=False)
    booking_id = db.Column(db.Integer, db.ForeignKey('bookings.id'), nullable=True)


class Notification(db.Model):
    __tablename__ = 'notifications'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    title = db.Column(db.String(200), nullable=False)
    message = db.Column(db.Text, nullable=False)
    type = db.Column(db.String(50), default='info')  # info, success, warning, booking, message
    is_read = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    link = db.Column(db.String(300), nullable=True)


class Annonce(db.Model):
    __tablename__ = 'annonces'
    id = db.Column(db.Integer, primary_key=True)
    author_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=False)
    type = db.Column(db.String(30), nullable=False)  # 'recrutement', 'demande_service', 'offre_service'
    category = db.Column(db.String(50), nullable=True)
    city = db.Column(db.String(50), nullable=True)
    price = db.Column(db.Float, nullable=True)
    is_paid = db.Column(db.Boolean, default=False)
    payment_id = db.Column(db.Integer, db.ForeignKey('payments.id'), nullable=True)
    image = db.Column(db.String(200), nullable=True)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    expires_at = db.Column(db.DateTime, nullable=True)
    views_count = db.Column(db.Integer, default=0)


class Payment(db.Model):
    __tablename__ = 'payments'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    currency = db.Column(db.String(10), default='MAD')
    type = db.Column(db.String(50), nullable=False)  # 'annonce', 'abonnement', 'service'
    status = db.Column(db.String(20), default='pending')  # pending, completed, failed
    reference = db.Column(db.String(100), unique=True, nullable=False)
    description = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    completed_at = db.Column(db.DateTime, nullable=True)


class SubscriptionPlan(db.Model):
    __tablename__ = 'subscription_plans'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    slug = db.Column(db.String(50), unique=True, nullable=False)
    description = db.Column(db.Text, nullable=True)
    price = db.Column(db.Float, nullable=False)
    duration_days = db.Column(db.Integer, nullable=False)
    annonce_limit = db.Column(db.Integer, default=0)
    features = db.Column(db.Text, nullable=True)  # JSON list
    is_active = db.Column(db.Boolean, default=True)
    target_type = db.Column(db.String(30), nullable=False)  # 'entreprise', 'autoentrepreneur', 'freelance'
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # Relationships
    subscribers = db.relationship('User', backref='subscription_plan', lazy=True)


class AppConfig(db.Model):
    __tablename__ = 'app_config'
    id = db.Column(db.Integer, primary_key=True)
    annonce_price = db.Column(db.Float, default=20.0)
    free_announces_new_user = db.Column(db.Integer, default=5)
    annonce_duration_days = db.Column(db.Integer, default=30)
    contact_email = db.Column(db.String(120), default='info@lmawqef.ma')
    contact_phone = db.Column(db.String(20), default='+212 5XX-XXXXXX')
    updated_at = db.Column(db.DateTime, default=datetime.utcnow)

    @staticmethod
    def get():
        config = AppConfig.query.first()
        if not config:
            config = AppConfig()
            db.session.add(config)
            db.session.commit()
        return config


class ContactMessage(db.Model):
    __tablename__ = 'contact_messages'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), nullable=False)
    subject = db.Column(db.String(200), nullable=False)
    message = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_read = db.Column(db.Boolean, default=False)


class AdminRole(db.Model):
    __tablename__ = 'admin_roles'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    can_manage_users = db.Column(db.Boolean, default=True)
    can_manage_services = db.Column(db.Boolean, default=True)
    can_manage_bookings = db.Column(db.Boolean, default=True)
    can_manage_annonces = db.Column(db.Boolean, default=True)
    can_manage_subscriptions = db.Column(db.Boolean, default=True)
    can_manage_payments = db.Column(db.Boolean, default=True)
    can_manage_admins = db.Column(db.Boolean, default=False)  # Only super admin
    can_edit_config = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    user = db.relationship('User', backref='admin_role')


# ==================== CATEGORIES ====================

CATEGORIES = [
    'IT & Technology', 'Construction & Renovation', 'Cleaning & Housekeeping',
    'Transport & Logistics', 'Plumbing & Electrical', 'Carpentry & Woodwork',
    'Painting & Decoration', 'Gardening & Landscaping', 'Automotive & Mechanics',
    'Education & Tutoring', 'Health & Wellness', 'Photography & Events',
    'Legal & Accounting', 'Marketing & Design', 'Other'
]

MOROCCAN_CITIES = [
    'Casablanca', 'Rabat', 'Marrakech', 'Fes', 'Tangier',
    'Agadir', 'Oujda', 'Kenitra', 'Tetouan', 'Safi',
    'El Jadida', 'Nador', 'Khouribga', 'Beni Mellal', 'Mohammedia',
    'Laayoune', 'Dakhla', 'Essaouira', 'Taza', 'Settat',
    'Berrechid', 'Khemisset', 'Ouarzazate', 'Al Hoceima', 'Errachidia'
]

ANNONCE_TYPES = [
    ('recrutement', 'Recrutement de profils'),
    ('demande_service', 'Demande de service'),
    ('offre_service', 'Offre de service')
]

ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'webp'}

# ==================== HELPERS ====================

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


def generate_reference():
    return 'LMQ' + ''.join(random.choices(string.ascii_uppercase + string.digits, k=10))


def save_uploaded_file(file, folder):
    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        # Add timestamp to avoid conflicts
        name, ext = os.path.splitext(filename)
        filename = f"{name}_{int(datetime.utcnow().timestamp())}{ext}"
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], folder, filename)
        file.save(filepath)
        return f"uploads/{folder}/{filename}"
    return None


# ==================== DECORATORS ====================

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please log in to access this page.', 'warning')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function


def worker_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please log in to access this page.', 'warning')
            return redirect(url_for('login'))
        user = User.query.get(session['user_id'])
        if user.user_type not in ['worker', 'entreprise']:
            flash('Only workers can access this page.', 'danger')
            return redirect(url_for('index'))
        return f(*args, **kwargs)
    return decorated_function


def entreprise_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please log in.', 'warning')
            return redirect(url_for('login'))
        user = User.query.get(session['user_id'])
        if user.user_type != 'entreprise':
            flash('Only enterprises can access this page.', 'danger')
            return redirect(url_for('index'))
        return f(*args, **kwargs)
    return decorated_function


def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please log in to access this page.', 'warning')
            return redirect(url_for('login'))
        user = User.query.get(session['user_id'])
        if not user.is_admin:
            flash('Admin access required.', 'danger')
            return redirect(url_for('index'))
        return f(*args, **kwargs)
    return decorated_function


def admin_permission_required(permission):
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if 'user_id' not in session:
                flash('Please log in.', 'warning')
                return redirect(url_for('login'))
            user = User.query.get(session['user_id'])
            if not user.is_admin:
                flash('Admin access required.', 'danger')
                return redirect(url_for('index'))
            role = AdminRole.query.filter_by(user_id=user.id).first()
            if not role:
                # Super admin (created before roles existed)
                if not user.username == 'admin':
                    flash('Insufficient permissions.', 'danger')
                    return redirect(url_for('admin_panel'))
                return f(*args, **kwargs)
            if not getattr(role, permission, False):
                flash('You do not have permission for this action.', 'danger')
                return redirect(url_for('admin_panel'))
            return f(*args, **kwargs)
        return decorated_function
    return decorator


# ==================== CONTEXT PROCESSORS ====================

@app.context_processor
def inject_globals():
    user = None
    unread_notifications = 0
    unread_messages = 0
    if 'user_id' in session:
        user = User.query.get(session['user_id'])
        unread_notifications = Notification.query.filter_by(user_id=session['user_id'], is_read=False).count()
        unread_messages = Message.query.filter_by(receiver_id=session['user_id'], is_read=False).count()
    return {
        'categories': CATEGORIES,
        'cities': MOROCCAN_CITIES,
        'annonce_types': ANNONCE_TYPES,
        'now': datetime.utcnow(),
        'current_user': user,
        'unread_notifications': unread_notifications,
        'unread_messages': unread_messages
    }


# ==================== MAIN ROUTES ====================

@app.route('/')
def index():
    featured_services = Service.query.filter_by(is_active=True).order_by(Service.created_at.desc()).limit(6).all()
    top_workers = User.query.filter(User.user_type.in_(['worker', 'entreprise'])).all()
    top_workers = sorted(top_workers, key=lambda w: w.average_rating(), reverse=True)[:4]
    stats = {
        'workers': User.query.filter(User.user_type.in_(['worker', 'entreprise'])).count(),
        'clients': User.query.filter_by(user_type='client').count(),
        'services': Service.query.filter_by(is_active=True).count(),
        'bookings': Booking.query.count(),
        'annonces': Annonce.query.filter_by(is_active=True).count(),
        'entreprises': User.query.filter_by(user_type='entreprise').count()
    }
    return render_template('index.html', featured_services=featured_services, top_workers=top_workers, stats=stats)


@app.route('/services')
def services():
    page = request.args.get('page', 1, type=int)
    search = request.args.get('search', '')
    category = request.args.get('category', '')
    city = request.args.get('city', '')
    min_price = request.args.get('min_price', type=float)
    max_price = request.args.get('max_price', type=float)

    query = Service.query.filter_by(is_active=True)

    if search:
        query = query.filter(db.or_(Service.title.contains(search), Service.description.contains(search)))
    if category:
        query = query.filter_by(category=category)
    if city:
        query = query.filter_by(city=city)
    if min_price is not None:
        query = query.filter(Service.price >= min_price)
    if max_price is not None:
        query = query.filter(Service.price <= max_price)

    services = query.order_by(Service.created_at.desc()).paginate(page=page, per_page=12, error_out=False)
    return render_template('services.html', services=services, search=search, category=category, city=city,
                         min_price=min_price, max_price=max_price)


@app.route('/service/<int:id>')
def service_detail(id):
    service = Service.query.get_or_404(id)
    service.views_count += 1
    db.session.commit()
    reviews = Review.query.filter_by(worker_id=service.worker_id).order_by(Review.created_at.desc()).all()
    related = Service.query.filter(Service.category == service.category, Service.id != service.id).limit(4).all()
    has_booked = False
    if 'user_id' in session:
        has_booked = Booking.query.filter_by(client_id=session['user_id'], service_id=service.id).first() is not None
    return render_template('service_detail.html', service=service, reviews=reviews,
                         related_services=related, has_booked=has_booked)


@app.route('/service/add', methods=['GET', 'POST'])
@login_required
def add_service():
    user = User.query.get(session['user_id'])
    if user.user_type not in ['worker', 'entreprise']:
        flash('Only workers can add services.', 'danger')
        return redirect(url_for('index'))

    if request.method == 'POST':
        title = request.form.get('title')
        category = request.form.get('category')
        description = request.form.get('description')
        price = request.form.get('price')
        city = request.form.get('city')
        address = request.form.get('address')

        if not all([title, category, description, price, city]):
            flash('All required fields must be filled.', 'danger')
            return redirect(url_for('add_service'))

        try:
            price = float(price)
        except ValueError:
            flash('Invalid price.', 'danger')
            return redirect(url_for('add_service'))

        service = Service(title=title, category=category, description=description,
                        price=price, city=city, worker_id=session['user_id'],
                        address=address)
        db.session.add(service)
        db.session.flush()

        # Handle multiple image uploads
        if 'images' in request.files:
            files = request.files.getlist('images')
            for file in files:
                if file and file.filename:
                    img_path = save_uploaded_file(file, 'services')
                    if img_path:
                        si = ServiceImage(service_id=service.id, filename=img_path)
                        db.session.add(si)

        # Handle main image
        if 'main_image' in request.files:
            file = request.files['main_image']
            if file and file.filename:
                img_path = save_uploaded_file(file, 'services')
                if img_path:
                    service.image = img_path

        db.session.commit()
        flash('Service added successfully!', 'success')
        return redirect(url_for('my_services'))

    return render_template('add_service.html')


@app.route('/service/edit/<int:id>', methods=['GET', 'POST'])
@login_required
def edit_service(id):
    service = Service.query.get_or_404(id)
    if service.worker_id != session['user_id']:
        flash('You can only edit your own services.', 'danger')
        return redirect(url_for('my_services'))

    if request.method == 'POST':
        service.title = request.form.get('title')
        service.category = request.form.get('category')
        service.description = request.form.get('description')
        service.price = float(request.form.get('price'))
        service.city = request.form.get('city')
        service.address = request.form.get('address')
        service.is_active = request.form.get('is_active') == 'on'

        # Handle new images
        if 'images' in request.files:
            files = request.files.getlist('images')
            for file in files:
                if file and file.filename:
                    img_path = save_uploaded_file(file, 'services')
                    if img_path:
                        si = ServiceImage(service_id=service.id, filename=img_path)
                        db.session.add(si)

        db.session.commit()
        flash('Service updated successfully!', 'success')
        return redirect(url_for('my_services'))

    return render_template('edit_service.html', service=service)


@app.route('/service/delete/<int:id>', methods=['POST'])
@login_required
def delete_service(id):
    service = Service.query.get_or_404(id)
    if service.worker_id != session['user_id']:
        flash('Unauthorized.', 'danger')
        return redirect(url_for('my_services'))
    db.session.delete(service)
    db.session.commit()
    flash('Service deleted.', 'success')
    return redirect(url_for('my_services'))


@app.route('/my-services')
@login_required
def my_services():
    user = User.query.get(session['user_id'])
    if user.user_type not in ['worker', 'entreprise']:
        flash('Only workers have services.', 'danger')
        return redirect(url_for('index'))
    services = Service.query.filter_by(worker_id=session['user_id']).order_by(Service.created_at.desc()).all()
    return render_template('my_services.html', services=services)


@app.route('/book-service/<int:service_id>', methods=['POST'])
@login_required
def book_service(service_id):
    service = Service.query.get_or_404(service_id)
    user = User.query.get(session['user_id'])
    if user.user_type not in ['client']:
        flash('Only clients can book services.', 'danger')
        return redirect(url_for('service_detail', id=service_id))

    message = request.form.get('message')
    if not message:
        flash('Please include a message.', 'danger')
        return redirect(url_for('service_detail', id=service_id))

    booking = Booking(client_id=session['user_id'], service_id=service_id, message=message)
    db.session.add(booking)
    db.session.flush()

    # Create notification for worker
    notif = Notification(user_id=service.worker_id, title='Nouvelle reservation',
                        message=f'{user.full_name} a reserve votre service "{service.title}"',
                        type='booking', link=f'/my-bookings')
    db.session.add(notif)

    db.session.commit()
    flash('Booking request sent!', 'success')
    return redirect(url_for('service_detail', id=service_id))


@app.route('/my-bookings')
@login_required
def my_bookings():
    user = User.query.get(session['user_id'])
    if user.user_type == 'client':
        bookings = Booking.query.filter_by(client_id=session['user_id']).order_by(Booking.created_at.desc()).all()
    else:
        bookings = Booking.query.join(Service).filter(Service.worker_id == session['user_id']).order_by(Booking.created_at.desc()).all()
    return render_template('my_bookings.html', bookings=bookings)


@app.route('/booking/update/<int:id>', methods=['POST'])
@login_required
def update_booking(id):
    booking = Booking.query.get_or_404(id)
    service = Service.query.get(booking.service_id)
    if service.worker_id != session['user_id']:
        flash('Unauthorized.', 'danger')
        return redirect(url_for('my_bookings'))

    status = request.form.get('status')
    if status in ['accepted', 'rejected', 'completed']:
        booking.status = status
        booking.updated_at = datetime.utcnow()

        # Notify client
        client_notif = Notification(user_id=booking.client_id, title='Reservation mise a jour',
                                   message=f'Votre reservation pour "{service.title}" est {status}',
                                   type='success', link='/my-bookings')
        db.session.add(client_notif)

        db.session.commit()
        flash(f'Booking {status}!', 'success')
    return redirect(url_for('my_bookings'))


@app.route('/review/<int:worker_id>', methods=['POST'])
@login_required
def add_review(worker_id):
    user = User.query.get(session['user_id'])
    if user.user_type != 'client':
        flash('Only clients can leave reviews.', 'danger')
        return redirect(url_for('profile', id=worker_id))

    rating = request.form.get('rating', type=int)
    comment = request.form.get('comment')
    if not rating or not comment or rating < 1 or rating > 5:
        flash('Valid rating and comment required.', 'danger')
        return redirect(url_for('profile', id=worker_id))

    has_booked = Booking.query.join(Service).filter(Booking.client_id == session['user_id'],
                                                    Service.worker_id == worker_id).first()
    if not has_booked:
        flash('You can only review workers you have booked.', 'danger')
        return redirect(url_for('profile', id=worker_id))

    existing = Review.query.filter_by(client_id=session['user_id'], worker_id=worker_id).first()
    if existing:
        flash('You already reviewed this worker.', 'danger')
        return redirect(url_for('profile', id=worker_id))

    review = Review(rating=rating, comment=comment, client_id=session['user_id'], worker_id=worker_id)
    db.session.add(review)

    # Notify worker
    worker = User.query.get(worker_id)
    notif = Notification(user_id=worker_id, title='Nouvel avis',
                        message=f'{user.full_name} vous a donne {rating} etoiles',
                        type='success', link=f'/profile/{worker_id}')
    db.session.add(notif)

    db.session.commit()
    flash('Review added!', 'success')
    return redirect(url_for('profile', id=worker_id))


@app.route('/profile/<int:id>')
def profile(id):
    user = User.query.get_or_404(id)
    services = Service.query.filter_by(worker_id=id, is_active=True).all() if user.user_type in ['worker', 'entreprise'] else []
    reviews = Review.query.filter_by(worker_id=id).order_by(Review.created_at.desc()).all()
    portfolio = PortfolioItem.query.filter_by(user_id=id).order_by(PortfolioItem.created_at.desc()).all()
    return render_template('profile.html', user=user, services=services, reviews=reviews, portfolio=portfolio)


@app.route('/my-profile', methods=['GET', 'POST'])
@login_required
def my_profile():
    user = User.query.get(session['user_id'])

    if request.method == 'POST':
        user.full_name = request.form.get('full_name')
        user.phone = request.form.get('phone')
        user.city = request.form.get('city')
        user.description = request.form.get('description')
        user.address = request.form.get('address')
        user.company_name = request.form.get('company_name')

        if user.user_type in ['worker', 'entreprise']:
            user.skills = request.form.get('skills')
            user.rc_number = request.form.get('rc_number')
            user.ice_number = request.form.get('ice_number')

        # Handle avatar upload
        if 'avatar' in request.files:
            file = request.files['avatar']
            if file and file.filename:
                img_path = save_uploaded_file(file, 'profiles')
                if img_path:
                    user.avatar = img_path

        # Handle portfolio upload
        if 'portfolio_files' in request.files:
            files = request.files.getlist('portfolio_files')
            for file in files:
                if file and file.filename:
                    img_path = save_uploaded_file(file, 'portfolio')
                    if img_path:
                        pi = PortfolioItem(user_id=user.id, title=request.form.get('portfolio_title', 'Portfolio'),
                                       filename=img_path)
                        db.session.add(pi)

        # Handle location
        lat = request.form.get('latitude')
        lng = request.form.get('longitude')
        if lat and lng:
            try:
                user.latitude = float(lat)
                user.longitude = float(lng)
            except ValueError:
                pass

        db.session.commit()
        flash('Profile updated!', 'success')
        return redirect(url_for('my_profile'))

    portfolio = PortfolioItem.query.filter_by(user_id=user.id).order_by(PortfolioItem.created_at.desc()).all()
    return render_template('my_profile.html', user=user, portfolio=portfolio)


@app.route('/portfolio/delete/<int:id>', methods=['POST'])
@login_required
def delete_portfolio(id):
    item = PortfolioItem.query.get_or_404(id)
    if item.user_id != session['user_id']:
        flash('Unauthorized.', 'danger')
        return redirect(url_for('my_profile'))
    db.session.delete(item)
    db.session.commit()
    flash('Portfolio item removed.', 'success')
    return redirect(url_for('my_profile'))


@app.route('/workers')
def workers():
    page = request.args.get('page', 1, type=int)
    city = request.args.get('city', '')
    skill = request.args.get('skill', '')
    user_type = request.args.get('user_type', '')

    query = User.query.filter(User.user_type.in_(['worker', 'entreprise']))
    if city:
        query = query.filter_by(city=city)
    if skill:
        query = query.filter(User.skills.contains(skill))
    if user_type:
        query = query.filter_by(user_type=user_type)

    workers = query.order_by(User.created_at.desc()).paginate(page=page, per_page=12, error_out=False)
    return render_template('workers.html', workers=workers, city=city, skill=skill, user_type=user_type)


# ==================== AUTH ROUTES ====================

@app.route('/register', methods=['GET', 'POST'])
def register():
    if 'user_id' in session:
        return redirect(url_for('index'))

    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        confirm = request.form.get('confirm_password')
        full_name = request.form.get('full_name')
        phone = request.form.get('phone')
        city = request.form.get('city')
        user_type = request.form.get('user_type')

        if not all([username, email, password, confirm, full_name, phone, city, user_type]):
            flash('All fields are required.', 'danger')
            return redirect(url_for('register'))

        if password != confirm:
            flash('Passwords do not match.', 'danger')
            return redirect(url_for('register'))
        if len(password) < 6:
            flash('Password must be at least 6 characters.', 'danger')
            return redirect(url_for('register'))

        if User.query.filter_by(username=username).first():
            flash('Username already exists.', 'danger')
            return redirect(url_for('register'))
        if User.query.filter_by(email=email).first():
            flash('Email already registered.', 'danger')
            return redirect(url_for('register'))

        user = User(username=username, email=email, password_hash=generate_password_hash(password),
                   full_name=full_name, phone=phone, city=city, user_type=user_type,
                   skills=request.form.get('skills', '') if user_type in ['worker', 'entreprise'] else None,
                   description=request.form.get('description', ''),
                   company_name=request.form.get('company_name', '') if user_type == 'entreprise' else None,
                   rc_number=request.form.get('rc_number', '') if user_type == 'entreprise' else None,
                   ice_number=request.form.get('ice_number', '') if user_type == 'entreprise' else None,
                   worker_subtype=request.form.get('worker_subtype') if user_type == 'worker' else None)

        db.session.add(user)
        db.session.commit()

        flash('Registration successful! Please log in.', 'success')
        return redirect(url_for('login'))

    return render_template('register.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if 'user_id' in session:
        return redirect(url_for('index'))

    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        user = User.query.filter_by(username=username).first()

        if user and check_password_hash(user.password_hash, password):
            if not user.is_active:
                flash('Your account has been deactivated. Contact support.', 'danger')
                return redirect(url_for('login'))

            session['user_id'] = user.id
            session['username'] = user.username
            session['user_type'] = user.user_type
            flash(f'Welcome back, {user.full_name}!', 'success')

            next_page = request.args.get('next')
            if next_page:
                return redirect(next_page)
            return redirect(url_for('index'))
        else:
            flash('Invalid username or password.', 'danger')

    return render_template('login.html')


@app.route('/logout')
def logout():
    session.clear()
    flash('You have been logged out.', 'info')
    return redirect(url_for('index'))


# ==================== DASHBOARD PRO ROUTES ====================

@app.route('/dashboard')
@login_required
def dashboard():
    user = User.query.get(session['user_id'])

    if user.user_type == 'entreprise':
        return redirect(url_for('dashboard_entreprise'))
    elif user.user_type == 'worker':
        return redirect(url_for('dashboard_worker'))
    else:
        return redirect(url_for('dashboard_client'))


@app.route('/dashboard/worker')
@login_required
def dashboard_worker():
    user = User.query.get(session['user_id'])
    if user.user_type not in ['worker', 'entreprise']:
        flash('Access denied.', 'danger')
        return redirect(url_for('index'))

    total_services = Service.query.filter_by(worker_id=user.id).count()
    active_services = Service.query.filter_by(worker_id=user.id, is_active=True).count()
    total_bookings = Booking.query.join(Service).filter(Service.worker_id == user.id).count()
    pending_bookings = Booking.query.join(Service).filter(Service.worker_id == user.id, Booking.status == 'pending').count()
    completed_bookings = Booking.query.join(Service).filter(Service.worker_id == user.id, Booking.status == 'completed').count()
    avg_rating = user.average_rating()
    total_reviews = user.review_count()
    total_views = db.session.query(db.func.sum(Service.views_count)).filter_by(worker_id=user.id).scalar() or 0

    # Monthly stats for chart
    current_month = datetime.utcnow().month
    monthly_bookings = Booking.query.join(Service).filter(
        Service.worker_id == user.id,
        db.extract('month', Booking.created_at) == current_month
    ).count()

    recent_bookings = Booking.query.join(Service).filter(Service.worker_id == user.id).order_by(Booking.created_at.desc()).limit(5).all()

    # Subscription info
    subscription = None
    if user.has_active_subscription():
        subscription = user.subscription_plan

    stats = {
        'total_services': total_services,
        'active_services': active_services,
        'total_bookings': total_bookings,
        'pending_bookings': pending_bookings,
        'completed_bookings': completed_bookings,
        'avg_rating': avg_rating,
        'total_reviews': total_reviews,
        'total_views': total_views,
        'monthly_bookings': monthly_bookings
    }

    return render_template('dashboard_worker.html', stats=stats, recent_bookings=recent_bookings,
                         subscription=subscription, user=user)


@app.route('/dashboard/client')
@login_required
def dashboard_client():
    user = User.query.get(session['user_id'])
    if user.user_type != 'client':
        return redirect(url_for('dashboard'))

    total_bookings = Booking.query.filter_by(client_id=user.id).count()
    pending_bookings = Booking.query.filter_by(client_id=user.id, status='pending').count()
    completed_bookings = Booking.query.filter_by(client_id=user.id, status='completed').count()
    total_reviews = Review.query.filter_by(client_id=user.id).count()

    recent_bookings = Booking.query.filter_by(client_id=user.id).order_by(Booking.created_at.desc()).limit(5).all()

    stats = {
        'total_bookings': total_bookings,
        'pending_bookings': pending_bookings,
        'completed_bookings': completed_bookings,
        'total_reviews': total_reviews
    }

    return render_template('dashboard_client.html', stats=stats, recent_bookings=recent_bookings)


@app.route('/dashboard/entreprise')
@login_required
def dashboard_entreprise():
    user = User.query.get(session['user_id'])
    if user.user_type != 'entreprise':
        flash('Access denied.', 'danger')
        return redirect(url_for('index'))

    total_services = Service.query.filter_by(worker_id=user.id).count()
    total_bookings = Booking.query.join(Service).filter(Service.worker_id == user.id).count()
    pending_bookings = Booking.query.join(Service).filter(Service.worker_id == user.id, Booking.status == 'pending').count()
    avg_rating = user.average_rating()

    # Workers managed by this enterprise
    managed_workers = User.query.filter_by(user_type='worker').all()  # In a real app, link workers to enterprises

    recent_bookings = Booking.query.join(Service).filter(Service.worker_id == user.id).order_by(Booking.created_at.desc()).limit(5).all()

    subscription = None
    if user.has_active_subscription():
        subscription = user.subscription_plan

    stats = {
        'total_services': total_services,
        'total_bookings': total_bookings,
        'pending_bookings': pending_bookings,
        'avg_rating': avg_rating,
        'total_reviews': user.review_count()
    }

    return render_template('dashboard_entreprise.html', stats=stats, recent_bookings=recent_bookings,
                         subscription=subscription, user=user)


# ==================== CHAT ROUTES ====================

@app.route('/messages')
@login_required
def messages():
    user = User.query.get(session['user_id'])

    # Get all conversations
    sent = Message.query.filter_by(sender_id=user.id).all()
    received = Message.query.filter_by(receiver_id=user.id).all()

    conversation_ids = set()
    for m in sent:
        conversation_ids.add(m.receiver_id)
    for m in received:
        conversation_ids.add(m.sender_id)

    conversations = []
    for uid in conversation_ids:
        other = User.query.get(uid)
        if other:
            last_msg = Message.query.filter(
                db.or_(
                    db.and_(Message.sender_id == user.id, Message.receiver_id == uid),
                    db.and_(Message.sender_id == uid, Message.receiver_id == user.id)
                )
            ).order_by(Message.created_at.desc()).first()
            unread = Message.query.filter_by(sender_id=uid, receiver_id=user.id, is_read=False).count()
            conversations.append({'user': other, 'last_message': last_msg, 'unread': unread})

    conversations.sort(key=lambda x: x['last_message'].created_at if x['last_message'] else datetime.min, reverse=True)

    # Selected conversation
    selected_id = request.args.get('with', type=int)
    selected_user = User.query.get(selected_id) if selected_id else None
    messages_list = []

    if selected_user:
        messages_list = Message.query.filter(
            db.or_(
                db.and_(Message.sender_id == user.id, Message.receiver_id == selected_id),
                db.and_(Message.sender_id == selected_id, Message.receiver_id == user.id)
            )
        ).order_by(Message.created_at.asc()).all()

        # Mark as read
        for msg in messages_list:
            if msg.receiver_id == user.id and not msg.is_read:
                msg.is_read = True
        db.session.commit()

    return render_template('messages.html', conversations=conversations, selected_user=selected_user,
                         messages_list=messages_list)


@app.route('/messages/send', methods=['POST'])
@login_required
def send_message():
    receiver_id = request.form.get('receiver_id', type=int)
    content = request.form.get('content')

    if not receiver_id or not content:
        return jsonify({'success': False, 'error': 'Missing data'})

    receiver = User.query.get(receiver_id)
    if not receiver:
        return jsonify({'success': False, 'error': 'User not found'})

    msg = Message(sender_id=session['user_id'], receiver_id=receiver_id, content=content)
    db.session.add(msg)

    # Create notification
    sender = User.query.get(session['user_id'])
    notif = Notification(user_id=receiver_id, title='Nouveau message',
                        message=f'{sender.full_name}: {content[:50]}...',
                        type='message', link='/messages?with=' + str(session['user_id']))
    db.session.add(notif)
    db.session.commit()

    return jsonify({'success': True, 'message': {
        'id': msg.id,
        'content': msg.content,
        'created_at': msg.created_at.strftime('%H:%M'),
        'is_sender': True
    }})


@app.route('/api/messages/unread')
@login_required
def api_unread_messages():
    count = Message.query.filter_by(receiver_id=session['user_id'], is_read=False).count()
    return jsonify({'unread': count})


@app.route('/api/messages/poll')
@login_required
def poll_messages():
    with_id = request.args.get('with', type=int)
    last_id = request.args.get('last_id', 0, type=int)

    if not with_id:
        return jsonify({'messages': []})

    messages = Message.query.filter(
        db.or_(
            db.and_(Message.sender_id == session['user_id'], Message.receiver_id == with_id),
            db.and_(Message.sender_id == with_id, Message.receiver_id == session['user_id'])
        ),
        Message.id > last_id
    ).order_by(Message.created_at.asc()).all()

    # Mark as read
    for msg in messages:
        if msg.receiver_id == session['user_id']:
            msg.is_read = True
    db.session.commit()

    return jsonify({'messages': [{
        'id': m.id,
        'content': m.content,
        'created_at': m.created_at.strftime('%H:%M'),
        'is_sender': m.sender_id == session['user_id']
    } for m in messages]})


# ==================== NOTIFICATIONS ROUTES ====================

@app.route('/notifications')
@login_required
def notifications():
    notifs = Notification.query.filter_by(user_id=session['user_id']).order_by(Notification.created_at.desc()).all()
    # Mark all as read
    for n in notifs:
        if not n.is_read:
            n.is_read = True
    db.session.commit()
    return render_template('notifications.html', notifications=notifs)


@app.route('/api/notifications/unread')
@login_required
def api_unread_notifications():
    count = Notification.query.filter_by(user_id=session['user_id'], is_read=False).count()
    return jsonify({'unread': count})


@app.route('/notification/delete/<int:id>', methods=['POST'])
@login_required
def delete_notification(id):
    notif = Notification.query.get_or_404(id)
    if notif.user_id != session['user_id']:
        flash('Unauthorized.', 'danger')
        return redirect(url_for('notifications'))
    db.session.delete(notif)
    db.session.commit()
    flash('Notification deleted.', 'success')
    return redirect(url_for('notifications'))


# ==================== ANNONCES ROUTES ====================

@app.route('/annonces')
def annonces():
    page = request.args.get('page', 1, type=int)
    type_filter = request.args.get('type', '')
    category = request.args.get('category', '')
    city = request.args.get('city', '')

    query = Annonce.query.filter_by(is_active=True)
    query = query.filter(Annonce.expires_at > datetime.utcnow()) if True else query

    if type_filter:
        query = query.filter_by(type=type_filter)
    if category:
        query = query.filter_by(category=category)
    if city:
        query = query.filter_by(city=city)

    annonces = query.order_by(Annonce.created_at.desc()).paginate(page=page, per_page=12, error_out=False)
    return render_template('annonces.html', annonces=annonces, type_filter=type_filter,
                         category=category, city=city)


@app.route('/annonce/<int:id>')
def annonce_detail(id):
    annonce = Annonce.query.get_or_404(id)
    annonce.views_count += 1
    db.session.commit()
    return render_template('annonce_detail.html', annonce=annonce)


@app.route('/annonce/add', methods=['GET', 'POST'])
@login_required
def add_annonce():
    user = User.query.get(session['user_id'])
    config = AppConfig.get()

    if request.method == 'POST':
        title = request.form.get('title')
        description = request.form.get('description')
        type_a = request.form.get('type')
        category = request.form.get('category')
        city = request.form.get('city')
        price = request.form.get('price')

        if not all([title, description, type_a]):
            flash('Title, description and type are required.', 'danger')
            return redirect(url_for('add_annonce'))

        # Check if user can post for free
        can_free = user.can_post_free_announce()
        can_monthly = user.can_post_monthly_announce()

        price_float = float(price) if price else None

        # Check if payment is needed
        announce_price = user.get_announce_price()
        needs_payment = announce_price > 0 and not can_free and not can_monthly

        annonce = Annonce(
            author_id=user.id, title=title, description=description, type=type_a,
            category=category, city=city, price=price_float,
            expires_at=datetime.utcnow() + timedelta(days=config.annonce_duration_days)
        )

        # Handle image
        if 'image' in request.files:
            file = request.files['image']
            if file and file.filename:
                img_path = save_uploaded_file(file, 'annonces')
                if img_path:
                    annonce.image = img_path

        if not needs_payment:
            annonce.is_paid = True
            if can_free:
                user.free_announces_used += 1
            elif can_monthly:
                user.announces_month_used += 1

        db.session.add(annonce)
        db.session.flush()

        if needs_payment:
            # Redirect to payment
            db.session.commit()
            return redirect(url_for('payment_annonce', annonce_id=annonce.id))

        db.session.commit()
        flash('Annonce publiee avec succes!', 'success')
        return redirect(url_for('annonces'))

    return render_template('add_annonce.html', user=user, config=config)


@app.route('/payment/annonce/<int:annonce_id>')
@login_required
def payment_annonce(annonce_id):
    annonce = Annonce.query.get_or_404(annonce_id)
    if annonce.author_id != session['user_id']:
        flash('Unauthorized.', 'danger')
        return redirect(url_for('annonces'))

    config = AppConfig.get()
    price = config.annonce_price

    return render_template('payment.html', annonce=annonce, amount=price, type='annonce')


@app.route('/payment/process', methods=['POST'])
@login_required
def process_payment():
    payment_type = request.form.get('type')
    annonce_id = request.form.get('annonce_id', type=int)
    plan_id = request.form.get('plan_id', type=int)

    user = User.query.get(session['user_id'])

    if payment_type == 'annonce' and annonce_id:
        annonce = Annonce.query.get_or_404(annonce_id)
        config = AppConfig.get()
        amount = config.annonce_price

        # Create payment record
        ref = generate_reference()
        payment = Payment(user_id=user.id, amount=amount, type='annonce', reference=ref,
                          description=f'Paiement annonce: {annonce.title}')
        db.session.add(payment)
        db.session.flush()

        # Simulate payment processing (in production, integrate CMI or Stripe)
        # For demo, we auto-approve
        payment.status = 'completed'
        payment.completed_at = datetime.utcnow()

        annonce.is_paid = True
        annonce.payment_id = payment.id

        db.session.commit()
        flash('Paiement effectue avec succes! Votre annonce est maintenant en ligne.', 'success')
        return redirect(url_for('annonce_detail', id=annonce_id))

    elif payment_type == 'abonnement' and plan_id:
        plan = SubscriptionPlan.query.get_or_404(plan_id)

        ref = generate_reference()
        payment = Payment(user_id=user.id, amount=plan.price, type='abonnement', reference=ref,
                          description=f'Abonnement {plan.name}')
        db.session.add(payment)
        db.session.flush()

        payment.status = 'completed'
        payment.completed_at = datetime.utcnow()

        # Activate subscription
        user.subscription_plan_id = plan.id
        user.subscription_active = True
        user.subscription_start = datetime.utcnow()
        user.subscription_end = datetime.utcnow() + timedelta(days=plan.duration_days)
        user.announces_month_used = 0
        user.announces_month_reset = datetime.utcnow()

        db.session.commit()
        flash(f'Abonnement {plan.name} active avec succes!', 'success')
        return redirect(url_for('dashboard'))

    flash('Invalid payment request.', 'danger')
    return redirect(url_for('index'))


# ==================== SUBSCRIPTION ROUTES ====================

@app.route('/abonnements')
def abonnements():
    user = User.query.get(session['user_id']) if 'user_id' in session else None

    # Filter plans by user type if logged in
    if user:
        if user.user_type == 'entreprise':
            plans = SubscriptionPlan.query.filter_by(target_type='entreprise', is_active=True).all()
        elif user.user_type == 'worker':
            if user.worker_subtype == 'freelance':
                plans = SubscriptionPlan.query.filter(SubscriptionPlan.target_type.in_(['autoentrepreneur', 'freelance']), 
                                                      SubscriptionPlan.is_active == True).all()
            else:
                plans = SubscriptionPlan.query.filter_by(target_type='autoentrepreneur', is_active=True).all()
        else:
            plans = []
    else:
        plans = SubscriptionPlan.query.filter_by(is_active=True).all()

    return render_template('abonnements.html', plans=plans, user=user)


@app.route('/abonnement/subscribe/<int:plan_id>')
@login_required
def subscribe_plan(plan_id):
    plan = SubscriptionPlan.query.get_or_404(plan_id)
    user = User.query.get(session['user_id'])

    if plan.price == 0:
        # Free plan - activate immediately
        user.subscription_plan_id = plan.id
        user.subscription_active = True
        user.subscription_start = datetime.utcnow()
        user.subscription_end = datetime.utcnow() + timedelta(days=plan.duration_days)
        db.session.commit()
        flash(f'Abonnement {plan.name} active gratuitement!', 'success')
        return redirect(url_for('dashboard'))

    return redirect(url_for('payment_abonnement', plan_id=plan_id))


@app.route('/payment/abonnement/<int:plan_id>')
@login_required
def payment_abonnement(plan_id):
    plan = SubscriptionPlan.query.get_or_404(plan_id)
    return render_template('payment_abonnement.html', plan=plan)


@app.route('/abonnement/cancel')
@login_required
def cancel_subscription():
    user = User.query.get(session['user_id'])
    user.subscription_active = False
    user.subscription_end = datetime.utcnow()
    db.session.commit()
    flash('Votre abonnement a ete annule.', 'info')
    return redirect(url_for('dashboard'))


# ==================== CONTACT & STATIC PAGES ====================

@app.route('/contact', methods=['GET', 'POST'])
def contact():
    if request.method == 'POST':
        name = request.form.get('name')
        email = request.form.get('email')
        subject = request.form.get('subject')
        message = request.form.get('message')
        if not all([name, email, subject, message]):
            flash('All fields are required.', 'danger')
            return redirect(url_for('contact'))
        msg = ContactMessage(name=name, email=email, subject=subject, message=message)
        db.session.add(msg)
        db.session.commit()
        flash('Message sent!', 'success')
        return redirect(url_for('contact'))
    return render_template('contact.html')


@app.route('/about')
def about():
    stats = {
        'users': User.query.count(),
        'workers': User.query.filter(User.user_type.in_(['worker', 'entreprise'])).count(),
        'services': Service.query.filter_by(is_active=True).count(),
        'bookings': Booking.query.count(),
        'annonces': Annonce.query.filter_by(is_active=True).count()
    }
    return render_template('about.html', stats=stats)


@app.route('/categories')
def categories_page():
    category_counts = {}
    for cat in CATEGORIES:
        category_counts[cat] = Service.query.filter_by(category=cat, is_active=True).count()
    return render_template('categories.html', category_counts=category_counts)


@app.route('/uploads/<path:filename>')
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)


# ==================== ADMIN PANEL PRO ====================

@app.route('/admin')
@admin_required
def admin_panel():
    stats = {
        'total_users': User.query.count(),
        'total_workers': User.query.filter_by(user_type='worker').count(),
        'total_entreprises': User.query.filter_by(user_type='entreprise').count(),
        'total_clients': User.query.filter_by(user_type='client').count(),
        'total_services': Service.query.count(),
        'total_bookings': Booking.query.count(),
        'total_reviews': Review.query.count(),
        'total_messages': ContactMessage.query.count(),
        'total_annonces': Annonce.query.count(),
        'total_payments': Payment.query.filter_by(status='completed').count(),
        'revenue': db.session.query(db.func.sum(Payment.amount)).filter_by(status='completed').scalar() or 0,
        'active_subscriptions': User.query.filter_by(subscription_active=True).count(),
        'pending_bookings': Booking.query.filter_by(status='pending').count()
    }

    recent_users = User.query.order_by(User.created_at.desc()).limit(10).all()
    recent_services = Service.query.order_by(Service.created_at.desc()).limit(10).all()
    recent_bookings = Booking.query.order_by(Booking.created_at.desc()).limit(10).all()
    recent_payments = Payment.query.order_by(Payment.created_at.desc()).limit(10).all()
    messages = ContactMessage.query.order_by(ContactMessage.created_at.desc()).all()

    return render_template('admin_panel.html', stats=stats, recent_users=recent_users,
                         recent_services=recent_services, recent_bookings=recent_bookings,
                         recent_payments=recent_payments, messages=messages)


@app.route('/admin/users')
@admin_required
@admin_permission_required('can_manage_users')
def admin_users():
    page = request.args.get('page', 1, type=int)
    search = request.args.get('search', '')
    user_type = request.args.get('user_type', '')

    query = User.query
    if search:
        query = query.filter(db.or_(User.username.contains(search), User.email.contains(search),
                                     User.full_name.contains(search)))
    if user_type:
        query = query.filter_by(user_type=user_type)

    users = query.order_by(User.created_at.desc()).paginate(page=page, per_page=20, error_out=False)
    return render_template('admin_users.html', users=users, search=search, user_type=user_type)


@app.route('/admin/user/<int:id>/toggle-active', methods=['POST'])
@admin_required
@admin_permission_required('can_manage_users')
def toggle_user_active(id):
    user = User.query.get_or_404(id)
    if user.id == session['user_id']:
        flash('You cannot deactivate yourself.', 'danger')
    else:
        user.is_active = not user.is_active
        db.session.commit()
        flash(f'User {user.username} {"activated" if user.is_active else "deactivated"}.', 'success')
    return redirect(url_for('admin_users'))


@app.route('/admin/user/<int:id>/toggle-admin', methods=['POST'])
@admin_required
@admin_permission_required('can_manage_admins')
def toggle_admin(id):
    user = User.query.get_or_404(id)
    if user.id == session['user_id']:
        flash('You cannot remove your own admin status.', 'danger')
    else:
        user.is_admin = not user.is_admin
        if user.is_admin:
            # Create admin role with default permissions
            role = AdminRole.query.filter_by(user_id=user.id).first()
            if not role:
                role = AdminRole(user_id=user.id)
                db.session.add(role)
        db.session.commit()
        flash(f'Admin status updated for {user.username}.', 'success')
    return redirect(url_for('admin_users'))


@app.route('/admin/user/<int:id>/delete', methods=['POST'])
@admin_required
@admin_permission_required('can_manage_users')
def delete_user(id):
    user = User.query.get_or_404(id)
    if user.id == session['user_id']:
        flash('You cannot delete yourself.', 'danger')
    else:
        db.session.delete(user)
        db.session.commit()
        flash('User deleted.', 'success')
    return redirect(url_for('admin_users'))


@app.route('/admin/services')
@admin_required
@admin_permission_required('can_manage_services')
def admin_services():
    page = request.args.get('page', 1, type=int)
    search = request.args.get('search', '')

    query = Service.query
    if search:
        query = query.filter(db.or_(Service.title.contains(search), Service.description.contains(search)))

    services = query.order_by(Service.created_at.desc()).paginate(page=page, per_page=20, error_out=False)
    return render_template('admin_services.html', services=services, search=search)


@app.route('/admin/services/delete/<int:id>', methods=['POST'])
@admin_required
@admin_permission_required('can_manage_services')
def admin_delete_service(id):
    service = Service.query.get_or_404(id)
    db.session.delete(service)
    db.session.commit()
    flash('Service deleted.', 'success')
    return redirect(url_for('admin_services'))


@app.route('/admin/annonces')
@admin_required
@admin_permission_required('can_manage_annonces')
def admin_annonces():
    page = request.args.get('page', 1, type=int)
    annonces = Annonce.query.order_by(Annonce.created_at.desc()).paginate(page=page, per_page=20, error_out=False)
    return render_template('admin_annonces.html', annonces=annonces)


@app.route('/admin/annonces/delete/<int:id>', methods=['POST'])
@admin_required
@admin_permission_required('can_manage_annonces')
def admin_delete_annonce(id):
    annonce = Annonce.query.get_or_404(id)
    db.session.delete(annonce)
    db.session.commit()
    flash('Annonce deleted.', 'success')
    return redirect(url_for('admin_annonces'))


@app.route('/admin/subscriptions')
@admin_required
@admin_permission_required('can_manage_subscriptions')
def admin_subscriptions():
    plans = SubscriptionPlan.query.all()
    active_subs = User.query.filter_by(subscription_active=True).all()
    return render_template('admin_subscriptions.html', plans=plans, active_subs=active_subs)


@app.route('/admin/subscription/plan/add', methods=['POST'])
@admin_required
@admin_permission_required('can_manage_subscriptions')
def add_subscription_plan():
    plan = SubscriptionPlan(
        name=request.form.get('name'),
        slug=request.form.get('slug'),
        description=request.form.get('description'),
        price=float(request.form.get('price', 0)),
        duration_days=int(request.form.get('duration_days', 30)),
        annonce_limit=int(request.form.get('annonce_limit', 0)),
        features=request.form.get('features'),
        target_type=request.form.get('target_type')
    )
    db.session.add(plan)
    db.session.commit()
    flash('Plan added.', 'success')
    return redirect(url_for('admin_subscriptions'))


@app.route('/admin/subscription/plan/edit/<int:id>', methods=['POST'])
@admin_required
@admin_permission_required('can_manage_subscriptions')
def edit_subscription_plan(id):
    plan = SubscriptionPlan.query.get_or_404(id)
    plan.name = request.form.get('name')
    plan.description = request.form.get('description')
    plan.price = float(request.form.get('price', 0))
    plan.duration_days = int(request.form.get('duration_days', 30))
    plan.annonce_limit = int(request.form.get('annonce_limit', 0))
    plan.features = request.form.get('features')
    plan.target_type = request.form.get('target_type')
    plan.is_active = request.form.get('is_active') == 'on'
    db.session.commit()
    flash('Plan updated.', 'success')
    return redirect(url_for('admin_subscriptions'))


@app.route('/admin/payments')
@admin_required
@admin_permission_required('can_manage_payments')
def admin_payments():
    page = request.args.get('page', 1, type=int)
    payments = Payment.query.order_by(Payment.created_at.desc()).paginate(page=page, per_page=20, error_out=False)
    total_revenue = db.session.query(db.func.sum(Payment.amount)).filter_by(status='completed').scalar() or 0
    return render_template('admin_payments.html', payments=payments, total_revenue=total_revenue)


@app.route('/admin/config', methods=['GET', 'POST'])
@admin_required
@admin_permission_required('can_edit_config')
def admin_config():
    config = AppConfig.get()

    if request.method == 'POST':
        config.annonce_price = float(request.form.get('annonce_price', 20))
        config.free_announces_new_user = int(request.form.get('free_announces_new_user', 5))
        config.annonce_duration_days = int(request.form.get('annonce_duration_days', 30))
        config.contact_email = request.form.get('contact_email')
        config.contact_phone = request.form.get('contact_phone')
        config.updated_at = datetime.utcnow()
        db.session.commit()
        flash('Configuration updated.', 'success')
        return redirect(url_for('admin_config'))

    return render_template('admin_config.html', config=config)


@app.route('/admin/admins')
@admin_required
@admin_permission_required('can_manage_admins')
def admin_admins():
    admins = User.query.filter_by(is_admin=True).all()
    return render_template('admin_admins.html', admins=admins)


@app.route('/admin/admin/<int:id>/permissions', methods=['POST'])
@admin_required
@admin_permission_required('can_manage_admins')
def update_admin_permissions(id):
    role = AdminRole.query.filter_by(user_id=id).first()
    if not role:
        role = AdminRole(user_id=id)
        db.session.add(role)

    role.can_manage_users = request.form.get('can_manage_users') == 'on'
    role.can_manage_services = request.form.get('can_manage_services') == 'on'
    role.can_manage_bookings = request.form.get('can_manage_bookings') == 'on'
    role.can_manage_annonces = request.form.get('can_manage_annonces') == 'on'
    role.can_manage_subscriptions = request.form.get('can_manage_subscriptions') == 'on'
    role.can_manage_payments = request.form.get('can_manage_payments') == 'on'
    role.can_manage_admins = request.form.get('can_manage_admins') == 'on'
    role.can_edit_config = request.form.get('can_edit_config') == 'on'

    db.session.commit()
    flash('Permissions updated.', 'success')
    return redirect(url_for('admin_admins'))


# ==================== API ROUTES ====================

@app.route('/api/search')
def api_search():
    q = request.args.get('q', '')
    if not q or len(q) < 2:
        return jsonify({'services': [], 'workers': []})

    services = Service.query.filter(
        db.or_(Service.title.contains(q), Service.description.contains(q)),
        Service.is_active == True
    ).limit(5).all()

    workers = User.query.filter(
        db.or_(User.full_name.contains(q), User.skills.contains(q)),
        User.user_type.in_(['worker', 'entreprise'])
    ).limit(5).all()

    return jsonify({
        'services': [{'id': s.id, 'title': s.title, 'price': s.price, 'city': s.city} for s in services],
        'workers': [{'id': w.id, 'name': w.full_name, 'city': w.city, 'rating': w.average_rating()} for w in workers]
    })


# ==================== ERROR HANDLERS ====================

@app.errorhandler(404)
def not_found(error):
    return render_template('404.html'), 404


@app.errorhandler(500)
def internal_error(error):
    db.session.rollback()
    return render_template('500.html'), 500


# ==================== INITIALIZATION ====================

def create_default_data():
    # Create admin if not exists
    admin = User.query.filter_by(username='admin').first()
    if not admin:
        admin = User(
            username='admin', email='admin@lmawqef.ma',
            password_hash=generate_password_hash('admin123'),
            full_name='System Administrator', phone='0600000000',
            city='Rabat', user_type='client', is_admin=True
        )
        db.session.add(admin)
        # Create super admin role
        role = AdminRole(user_id=1, can_manage_users=True, can_manage_services=True,
                        can_manage_bookings=True, can_manage_annonces=True,
                        can_manage_subscriptions=True, can_manage_payments=True,
                        can_manage_admins=True, can_edit_config=True)
        db.session.add(role)
        db.session.commit()
        print('Admin created: admin / admin123')

    # Create default subscription plans
    plans = SubscriptionPlan.query.all()
    if not plans:
        default_plans = [
            SubscriptionPlan(name='Entreprise Premium', slug='entreprise-premium',
                           description='For workforce companies', price=500, duration_days=30,
                           annonce_limit=999, features='["Unlimited announces","Featured profile","Priority support"]',
                           target_type='entreprise'),
            SubscriptionPlan(name='Entreprise Basic', slug='entreprise-basic',
                           description='Basic plan for companies', price=0, duration_days=30,
                           annonce_limit=50, features='["50 announces/month","Basic support"]',
                           target_type='entreprise'),
            SubscriptionPlan(name='Auto-Entrepreneur Pro', slug='auto-pro',
                           description='For self-employed professionals', price=150, duration_days=30,
                           annonce_limit=100, features='["100 announces/month","Portfolio showcase","Priority listing"]',
                           target_type='autoentrepreneur'),
            SubscriptionPlan(name='Freelance Starter', slug='freelance-starter',
                           description='For freelancers', price=0, duration_days=30,
                           annonce_limit=20, features='["20 announces/month","Basic profile"]',
                           target_type='freelance'),
            SubscriptionPlan(name='Freelance Pro', slug='freelance-pro',
                           description='Pro plan for freelancers', price=100, duration_days=30,
                           annonce_limit=50, features='["50 announces/month","Portfolio","Featured services"]',
                           target_type='freelance')
        ]
        for p in default_plans:
            db.session.add(p)
        db.session.commit()
        print('Default subscription plans created')

    # Create app config
    config = AppConfig.query.first()
    if not config:
        config = AppConfig()
        db.session.add(config)
        db.session.commit()
        print('App config created')


if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        create_default_data()
    app.run(host='0.0.0.0', port=5000, debug=True)
