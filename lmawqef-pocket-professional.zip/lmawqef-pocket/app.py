#!/usr/bin/env python3
"""
Lmawqef Pocket - Moroccan Marketplace Platform
Connects clients with skilled workers and service providers
"""

from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps
from datetime import datetime
import os

app = Flask(__name__)
app.config['SECRET_KEY'] = 'lmawqef-pocket-secret-key-2026'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///lmawqef.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['UPLOAD_FOLDER'] = 'static/images'

db = SQLAlchemy(app)

# ==================== DATABASE MODELS ====================

class User(db.Model):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    full_name = db.Column(db.String(100), nullable=False)
    phone = db.Column(db.String(20), nullable=False)
    city = db.Column(db.String(50), nullable=False)
    user_type = db.Column(db.String(20), nullable=False)  # 'client' or 'worker'
    skills = db.Column(db.Text, nullable=True)
    description = db.Column(db.Text, nullable=True)
    avatar = db.Column(db.String(200), default='default-avatar.png')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_admin = db.Column(db.Boolean, default=False)

    # Relationships
    services = db.relationship('Service', backref='worker', lazy=True, cascade='all, delete-orphan')
    reviews_given = db.relationship('Review', foreign_keys='Review.client_id', backref='client', lazy=True)
    reviews_received = db.relationship('Review', foreign_keys='Review.worker_id', backref='reviewed_worker', lazy=True)
    bookings = db.relationship('Booking', foreign_keys='Booking.client_id', backref='client', lazy=True)

    def average_rating(self):
        reviews = Review.query.filter_by(worker_id=self.id).all()
        if not reviews:
            return 0
        return round(sum(r.rating for r in reviews) / len(reviews), 1)

    def review_count(self):
        return Review.query.filter_by(worker_id=self.id).count()


class Service(db.Model):
    __tablename__ = 'services'
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    category = db.Column(db.String(50), nullable=False)
    description = db.Column(db.Text, nullable=False)
    price = db.Column(db.Float, nullable=False)
    city = db.Column(db.String(50), nullable=False)
    worker_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    image = db.Column(db.String(200), default='default-service.jpg')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_active = db.Column(db.Boolean, default=True)

    # Relationships
    bookings = db.relationship('Booking', backref='service', lazy=True, cascade='all, delete-orphan')


class Review(db.Model):
    __tablename__ = 'reviews'
    id = db.Column(db.Integer, primary_key=True)
    rating = db.Column(db.Integer, nullable=False)
    comment = db.Column(db.Text, nullable=False)
    client_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    worker_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class Booking(db.Model):
    __tablename__ = 'bookings'
    id = db.Column(db.Integer, primary_key=True)
    client_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    service_id = db.Column(db.Integer, db.ForeignKey('services.id'), nullable=False)
    message = db.Column(db.Text, nullable=False)
    status = db.Column(db.String(20), default='pending')  # pending, accepted, rejected, completed
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class ContactMessage(db.Model):
    __tablename__ = 'contact_messages'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), nullable=False)
    subject = db.Column(db.String(200), nullable=False)
    message = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_read = db.Column(db.Boolean, default=False)


# ==================== CATEGORIES ====================

CATEGORIES = [
    'IT & Technology',
    'Construction & Renovation',
    'Cleaning & Housekeeping',
    'Transport & Logistics',
    'Plumbing & Electrical',
    'Carpentry & Woodwork',
    'Painting & Decoration',
    'Gardening & Landscaping',
    'Automotive & Mechanics',
    'Education & Tutoring',
    'Health & Wellness',
    'Photography & Events',
    'Legal & Accounting',
    'Marketing & Design',
    'Other'
]

MOROCCAN_CITIES = [
    'Casablanca', 'Rabat', 'Marrakech', 'Fes', 'Tangier',
    'Agadir', 'Oujda', 'Kenitra', 'Tetouan', 'Safi',
    'El Jadida', 'Nador', 'Khouribga', 'Beni Mellal', 'Mohammedia',
    'Laayoune', 'Dakhla', 'Essaouira', 'Taza', 'Settat',
    'Berrechid', 'Khemisset', 'Ouarzazate', 'Al Hoceima', 'Errachidia'
]


# ==================== DECORATORS ====================

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please log in to access this page.', 'warning')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function


def worker_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please log in to access this page.', 'warning')
            return redirect(url_for('login'))
        user = User.query.get(session['user_id'])
        if user.user_type != 'worker':
            flash('Only workers can access this page.', 'danger')
            return redirect(url_for('index'))
        return f(*args, **kwargs)
    return decorated_function


def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please log in to access this page.', 'warning')
            return redirect(url_for('login'))
        user = User.query.get(session['user_id'])
        if not user.is_admin:
            flash('Admin access required.', 'danger')
            return redirect(url_for('index'))
        return f(*args, **kwargs)
    return decorated_function


# ==================== CONTEXT PROCESSORS ====================

@app.context_processor
def inject_globals():
    return {
        'categories': CATEGORIES,
        'cities': MOROCCAN_CITIES,
        'now': datetime.utcnow()
    }


# ==================== ROUTES ====================

@app.route('/')
def index():
    featured_services = Service.query.filter_by(is_active=True).order_by(Service.created_at.desc()).limit(6).all()
    top_workers = User.query.filter_by(user_type='worker').all()
    top_workers = sorted(top_workers, key=lambda w: w.average_rating(), reverse=True)[:4]
    stats = {
        'workers': User.query.filter_by(user_type='worker').count(),
        'clients': User.query.filter_by(user_type='client').count(),
        'services': Service.query.filter_by(is_active=True).count(),
        'bookings': Booking.query.count()
    }
    return render_template('index.html', 
                         featured_services=featured_services, 
                         top_workers=top_workers,
                         stats=stats)


@app.route('/services')
def services():
    page = request.args.get('page', 1, type=int)
    search = request.args.get('search', '')
    category = request.args.get('category', '')
    city = request.args.get('city', '')
    min_price = request.args.get('min_price', type=float)
    max_price = request.args.get('max_price', type=float)

    query = Service.query.filter_by(is_active=True)

    if search:
        query = query.filter(
            db.or_(
                Service.title.contains(search),
                Service.description.contains(search)
            )
        )

    if category:
        query = query.filter_by(category=category)

    if city:
        query = query.filter_by(city=city)

    if min_price is not None:
        query = query.filter(Service.price >= min_price)

    if max_price is not None:
        query = query.filter(Service.price <= max_price)

    services = query.order_by(Service.created_at.desc()).paginate(
        page=page, per_page=12, error_out=False
    )

    return render_template('services.html', services=services, 
                         search=search, category=category, city=city,
                         min_price=min_price, max_price=max_price)


@app.route('/service/<int:id>')
def service_detail(id):
    service = Service.query.get_or_404(id)
    reviews = Review.query.filter_by(worker_id=service.worker_id).order_by(Review.created_at.desc()).all()
    related_services = Service.query.filter(
        Service.category == service.category,
        Service.id != service.id
    ).limit(4).all()

    has_booked = False
    if 'user_id' in session:
        has_booked = Booking.query.filter_by(
            client_id=session['user_id'],
            service_id=service.id
        ).first() is not None

    return render_template('service_detail.html', 
                         service=service, 
                         reviews=reviews,
                         related_services=related_services,
                         has_booked=has_booked)


@app.route('/service/add', methods=['GET', 'POST'])
@login_required
def add_service():
    user = User.query.get(session['user_id'])
    if user.user_type != 'worker':
        flash('Only workers can add services.', 'danger')
        return redirect(url_for('index'))

    if request.method == 'POST':
        title = request.form.get('title')
        category = request.form.get('category')
        description = request.form.get('description')
        price = request.form.get('price')
        city = request.form.get('city')

        if not all([title, category, description, price, city]):
            flash('All fields are required.', 'danger')
            return redirect(url_for('add_service'))

        try:
            price = float(price)
        except ValueError:
            flash('Invalid price.', 'danger')
            return redirect(url_for('add_service'))

        service = Service(
            title=title,
            category=category,
            description=description,
            price=price,
            city=city,
            worker_id=session['user_id']
        )

        db.session.add(service)
        db.session.commit()

        flash('Service added successfully!', 'success')
        return redirect(url_for('my_services'))

    return render_template('add_service.html')


@app.route('/service/edit/<int:id>', methods=['GET', 'POST'])
@login_required
def edit_service(id):
    service = Service.query.get_or_404(id)

    if service.worker_id != session['user_id']:
        flash('You can only edit your own services.', 'danger')
        return redirect(url_for('my_services'))

    if request.method == 'POST':
        service.title = request.form.get('title')
        service.category = request.form.get('category')
        service.description = request.form.get('description')
        service.price = float(request.form.get('price'))
        service.city = request.form.get('city')
        service.is_active = request.form.get('is_active') == 'on'

        db.session.commit()
        flash('Service updated successfully!', 'success')
        return redirect(url_for('my_services'))

    return render_template('edit_service.html', service=service)


@app.route('/service/delete/<int:id>', methods=['POST'])
@login_required
def delete_service(id):
    service = Service.query.get_or_404(id)

    if service.worker_id != session['user_id']:
        flash('You can only delete your own services.', 'danger')
        return redirect(url_for('my_services'))

    db.session.delete(service)
    db.session.commit()
    flash('Service deleted successfully!', 'success')
    return redirect(url_for('my_services'))


@app.route('/my-services')
@login_required
def my_services():
    user = User.query.get(session['user_id'])
    if user.user_type != 'worker':
        flash('Only workers have services.', 'danger')
        return redirect(url_for('index'))

    services = Service.query.filter_by(worker_id=session['user_id']).order_by(Service.created_at.desc()).all()
    return render_template('my_services.html', services=services)


@app.route('/book-service/<int:service_id>', methods=['POST'])
@login_required
def book_service(service_id):
    service = Service.query.get_or_404(service_id)
    user = User.query.get(session['user_id'])

    if user.user_type != 'client':
        flash('Only clients can book services.', 'danger')
        return redirect(url_for('service_detail', id=service_id))

    message = request.form.get('message')
    if not message:
        flash('Please include a message.', 'danger')
        return redirect(url_for('service_detail', id=service_id))

    booking = Booking(
        client_id=session['user_id'],
        service_id=service_id,
        message=message
    )

    db.session.add(booking)
    db.session.commit()

    flash('Booking request sent successfully!', 'success')
    return redirect(url_for('service_detail', id=service_id))


@app.route('/my-bookings')
@login_required
def my_bookings():
    user = User.query.get(session['user_id'])

    if user.user_type == 'client':
        bookings = Booking.query.filter_by(client_id=session['user_id']).order_by(Booking.created_at.desc()).all()
    else:
        bookings = Booking.query.join(Service).filter(Service.worker_id == session['user_id']).order_by(Booking.created_at.desc()).all()

    return render_template('my_bookings.html', bookings=bookings)


@app.route('/booking/update/<int:id>', methods=['POST'])
@login_required
def update_booking(id):
    booking = Booking.query.get_or_404(id)
    service = Service.query.get(booking.service_id)

    if service.worker_id != session['user_id']:
        flash('Unauthorized.', 'danger')
        return redirect(url_for('my_bookings'))

    status = request.form.get('status')
    if status in ['accepted', 'rejected', 'completed']:
        booking.status = status
        db.session.commit()
        flash(f'Booking {status}!', 'success')

    return redirect(url_for('my_bookings'))


@app.route('/review/<int:worker_id>', methods=['POST'])
@login_required
def add_review(worker_id):
    user = User.query.get(session['user_id'])
    if user.user_type != 'client':
        flash('Only clients can leave reviews.', 'danger')
        return redirect(url_for('profile', id=worker_id))

    rating = request.form.get('rating', type=int)
    comment = request.form.get('comment')

    if not rating or not comment:
        flash('Rating and comment are required.', 'danger')
        return redirect(url_for('profile', id=worker_id))

    if rating < 1 or rating > 5:
        flash('Rating must be between 1 and 5.', 'danger')
        return redirect(url_for('profile', id=worker_id))

    # Check if client has booked a service from this worker
    has_booked = Booking.query.join(Service).filter(
        Booking.client_id == session['user_id'],
        Service.worker_id == worker_id
    ).first()

    if not has_booked:
        flash('You can only review workers you have booked services from.', 'danger')
        return redirect(url_for('profile', id=worker_id))

    # Check if already reviewed
    existing = Review.query.filter_by(client_id=session['user_id'], worker_id=worker_id).first()
    if existing:
        flash('You have already reviewed this worker.', 'danger')
        return redirect(url_for('profile', id=worker_id))

    review = Review(
        rating=rating,
        comment=comment,
        client_id=session['user_id'],
        worker_id=worker_id
    )

    db.session.add(review)
    db.session.commit()

    flash('Review added successfully!', 'success')
    return redirect(url_for('profile', id=worker_id))


@app.route('/profile/<int:id>')
def profile(id):
    user = User.query.get_or_404(id)
    services = Service.query.filter_by(worker_id=id, is_active=True).all() if user.user_type == 'worker' else []
    reviews = Review.query.filter_by(worker_id=id).order_by(Review.created_at.desc()).all()

    return render_template('profile.html', user=user, services=services, reviews=reviews)


@app.route('/my-profile', methods=['GET', 'POST'])
@login_required
def my_profile():
    user = User.query.get(session['user_id'])

    if request.method == 'POST':
        user.full_name = request.form.get('full_name')
        user.phone = request.form.get('phone')
        user.city = request.form.get('city')
        user.description = request.form.get('description')

        if user.user_type == 'worker':
            user.skills = request.form.get('skills')

        db.session.commit()
        flash('Profile updated successfully!', 'success')
        return redirect(url_for('my_profile'))

    return render_template('my_profile.html', user=user)


@app.route('/workers')
def workers():
    page = request.args.get('page', 1, type=int)
    city = request.args.get('city', '')
    skill = request.args.get('skill', '')

    query = User.query.filter_by(user_type='worker')

    if city:
        query = query.filter_by(city=city)

    if skill:
        query = query.filter(User.skills.contains(skill))

    workers = query.order_by(User.created_at.desc()).paginate(
        page=page, per_page=12, error_out=False
    )

    return render_template('workers.html', workers=workers, city=city, skill=skill)


@app.route('/register', methods=['GET', 'POST'])
def register():
    if 'user_id' in session:
        return redirect(url_for('index'))

    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        full_name = request.form.get('full_name')
        phone = request.form.get('phone')
        city = request.form.get('city')
        user_type = request.form.get('user_type')

        if not all([username, email, password, confirm_password, full_name, phone, city, user_type]):
            flash('All fields are required.', 'danger')
            return redirect(url_for('register'))

        if password != confirm_password:
            flash('Passwords do not match.', 'danger')
            return redirect(url_for('register'))

        if len(password) < 6:
            flash('Password must be at least 6 characters.', 'danger')
            return redirect(url_for('register'))

        if User.query.filter_by(username=username).first():
            flash('Username already exists.', 'danger')
            return redirect(url_for('register'))

        if User.query.filter_by(email=email).first():
            flash('Email already registered.', 'danger')
            return redirect(url_for('register'))

        user = User(
            username=username,
            email=email,
            password_hash=generate_password_hash(password),
            full_name=full_name,
            phone=phone,
            city=city,
            user_type=user_type,
            skills=request.form.get('skills', '') if user_type == 'worker' else None,
            description=request.form.get('description', '')
        )

        db.session.add(user)
        db.session.commit()

        flash('Registration successful! Please log in.', 'success')
        return redirect(url_for('login'))

    return render_template('register.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if 'user_id' in session:
        return redirect(url_for('index'))

    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        user = User.query.filter_by(username=username).first()

        if user and check_password_hash(user.password_hash, password):
            session['user_id'] = user.id
            session['username'] = user.username
            session['user_type'] = user.user_type
            flash(f'Welcome back, {user.full_name}!', 'success')

            next_page = request.args.get('next')
            if next_page:
                return redirect(next_page)
            return redirect(url_for('index'))
        else:
            flash('Invalid username or password.', 'danger')

    return render_template('login.html')


@app.route('/logout')
def logout():
    session.clear()
    flash('You have been logged out.', 'info')
    return redirect(url_for('index'))


@app.route('/dashboard')
@login_required
def dashboard():
    user = User.query.get(session['user_id'])

    if user.user_type == 'worker':
        total_services = Service.query.filter_by(worker_id=user.id).count()
        active_services = Service.query.filter_by(worker_id=user.id, is_active=True).count()
        total_bookings = Booking.query.join(Service).filter(Service.worker_id == user.id).count()
        pending_bookings = Booking.query.join(Service).filter(
            Service.worker_id == user.id,
            Booking.status == 'pending'
        ).count()
        avg_rating = user.average_rating()
        total_reviews = user.review_count()

        recent_bookings = Booking.query.join(Service).filter(
            Service.worker_id == user.id
        ).order_by(Booking.created_at.desc()).limit(5).all()

        stats = {
            'total_services': total_services,
            'active_services': active_services,
            'total_bookings': total_bookings,
            'pending_bookings': pending_bookings,
            'avg_rating': avg_rating,
            'total_reviews': total_reviews
        }

        return render_template('dashboard_worker.html', stats=stats, recent_bookings=recent_bookings)
    else:
        total_bookings = Booking.query.filter_by(client_id=user.id).count()
        pending_bookings = Booking.query.filter_by(client_id=user.id, status='pending').count()
        completed_bookings = Booking.query.filter_by(client_id=user.id, status='completed').count()

        recent_bookings = Booking.query.filter_by(client_id=user.id).order_by(
            Booking.created_at.desc()
        ).limit(5).all()

        stats = {
            'total_bookings': total_bookings,
            'pending_bookings': pending_bookings,
            'completed_bookings': completed_bookings
        }

        return render_template('dashboard_client.html', stats=stats, recent_bookings=recent_bookings)


@app.route('/admin')
@admin_required
def admin_panel():
    stats = {
        'total_users': User.query.count(),
        'total_workers': User.query.filter_by(user_type='worker').count(),
        'total_clients': User.query.filter_by(user_type='client').count(),
        'total_services': Service.query.count(),
        'total_bookings': Booking.query.count(),
        'total_reviews': Review.query.count(),
        'total_messages': ContactMessage.query.count()
    }

    recent_users = User.query.order_by(User.created_at.desc()).limit(10).all()
    recent_services = Service.query.order_by(Service.created_at.desc()).limit(10).all()
    recent_bookings = Booking.query.order_by(Booking.created_at.desc()).limit(10).all()
    messages = ContactMessage.query.order_by(ContactMessage.created_at.desc()).all()

    return render_template('admin_panel.html', 
                         stats=stats, 
                         recent_users=recent_users,
                         recent_services=recent_services,
                         recent_bookings=recent_bookings,
                         messages=messages)


@app.route('/admin/user/<int:id>/toggle-admin', methods=['POST'])
@admin_required
def toggle_admin(id):
    user = User.query.get_or_404(id)
    if user.id == session['user_id']:
        flash('You cannot remove your own admin status.', 'danger')
    else:
        user.is_admin = not user.is_admin
        db.session.commit()
        flash(f'Admin status updated for {user.username}.', 'success')
    return redirect(url_for('admin_panel'))


@app.route('/admin/user/<int:id>/delete', methods=['POST'])
@admin_required
def delete_user(id):
    user = User.query.get_or_404(id)
    if user.id == session['user_id']:
        flash('You cannot delete yourself.', 'danger')
    else:
        db.session.delete(user)
        db.session.commit()
        flash('User deleted successfully.', 'success')
    return redirect(url_for('admin_panel'))


@app.route('/contact', methods=['GET', 'POST'])
def contact():
    if request.method == 'POST':
        name = request.form.get('name')
        email = request.form.get('email')
        subject = request.form.get('subject')
        message = request.form.get('message')

        if not all([name, email, subject, message]):
            flash('All fields are required.', 'danger')
            return redirect(url_for('contact'))

        msg = ContactMessage(name=name, email=email, subject=subject, message=message)
        db.session.add(msg)
        db.session.commit()

        flash('Message sent successfully! We will get back to you soon.', 'success')
        return redirect(url_for('contact'))

    return render_template('contact.html')


@app.route('/about')
def about():
    return render_template('about.html')


@app.route('/categories')
def categories_page():
    category_counts = {}
    for cat in CATEGORIES:
        category_counts[cat] = Service.query.filter_by(category=cat, is_active=True).count()

    return render_template('categories.html', category_counts=category_counts)


# ==================== ERROR HANDLERS ====================

@app.errorhandler(404)
def not_found(error):
    return render_template('404.html'), 404


@app.errorhandler(500)
def internal_error(error):
    db.session.rollback()
    return render_template('500.html'), 500


# ==================== INITIALIZATION ====================

def create_admin():
    admin = User.query.filter_by(username='admin').first()
    if not admin:
        admin = User(
            username='admin',
            email='admin@lmawqef.ma',
            password_hash=generate_password_hash('admin123'),
            full_name='System Administrator',
            phone='0600000000',
            city='Rabat',
            user_type='client',
            is_admin=True
        )
        db.session.add(admin)
        db.session.commit()
        print('Admin user created: admin / admin123')


if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        create_admin()
    app.run(host='0.0.0.0', port=5000, debug=True)
