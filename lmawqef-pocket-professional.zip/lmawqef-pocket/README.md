# Lmawqef Pocket

A Moroccan marketplace platform that connects clients with skilled workers and service providers.

## Features

- **User System**: Register as Client or Worker, Login/Logout, Profile management
- **Service System**: Workers can add, edit, and delete services
- **Search & Filter**: Search by keyword, filter by category and city
- **Booking System**: Clients can request services from workers
- **Review System**: Clients can rate and review workers (1-5 stars)
- **Admin Panel**: Manage users, services, bookings, and messages
- **Dashboard**: Personalized dashboard for both clients and workers
- **Responsive Design**: Mobile-friendly modern UI

## Tech Stack

- **Backend**: Python Flask
- **Frontend**: HTML, CSS, JavaScript
- **Database**: SQLite with SQLAlchemy ORM
- **Authentication**: Session-based with Werkzeug security

## Installation

1. Install dependencies:
```bash
pip install -r requirements.txt
```

2. Run the application:
```bash
python app.py
```

3. Open your browser and go to `http://localhost:5000`

## Default Admin Account

- **Username**: admin
- **Password**: admin123

## Categories

- IT & Technology
- Construction & Renovation
- Cleaning & Housekeeping
- Transport & Logistics
- Plumbing & Electrical
- Carpentry & Woodwork
- Painting & Decoration
- Gardening & Landscaping
- Automotive & Mechanics
- Education & Tutoring
- Health & Wellness
- Photography & Events
- Legal & Accounting
- Marketing & Design
- Other

## Project Structure

```
lmawqef-pocket/
├── app.py                  # Main Flask application
├── requirements.txt        # Python dependencies
├── README.md              # This file
├── static/
│   ├── css/
│   │   └── style.css      # Main stylesheet
│   ├── js/
│   │   └── main.js        # Main JavaScript
│   └── images/            # Image uploads directory
└── templates/             # HTML templates
    ├── base.html
    ├── index.html
    ├── services.html
    ├── service_detail.html
    ├── add_service.html
    ├── edit_service.html
    ├── my_services.html
    ├── workers.html
    ├── profile.html
    ├── my_profile.html
    ├── login.html
    ├── register.html
    ├── my_bookings.html
    ├── dashboard_worker.html
    ├── dashboard_client.html
    ├── admin_panel.html
    ├── categories.html
    ├── about.html
    ├── contact.html
    ├── 404.html
    └── 500.html
```

## License

MIT License
